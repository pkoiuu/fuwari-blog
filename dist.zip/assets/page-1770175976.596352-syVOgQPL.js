import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>用来记录我所犯的错误:</p>\n<p>2025.8.25错误</p>\n<p>1.没有剔头发,不符合学校规则</p>\n<p>2.中午时候没怎么休息,没有去剔头发</p>\n<p>3.正步没有学好</p>\n<p>2025.8.25<strong>反思</strong></p>\n<p>(1)已经改正,第一时间去剔头发,等了四十分钟</p>\n<p>(2)军训期间中午(回来了到出发时间为3小时10分),三十分钟吃饭,三十分钟看视频/写自己的博客,剩下十分钟自己安排,其他时间休息</p>\n<p>(3) 今天8.26加强训练(已经差不多会了)hh</p>\n<p>2025.8.26错误</p>\n<p>1.正步不太行</p>\n<p>2.还没有学习/预习除了语数英的课程</p>\n<p>3.早点睡</p>\n<p>2025.8.26反思</p>\n<p>(1)哎,不好办,节奏不好,明天加油</p>\n<p>(2)在2025.8.29之前学习</p>\n<p>(3)在8:30前睡觉</p>\n<p>2025.8.27错误</p>\n<p>1.作文没有提前完成,中午才补</p>\n<p>2.正步还没学好</p>\n<p>3.中午没有更新网站</p>\n<p>2025.8.27反思</p>\n<p>(1)以后作业早点做</p>\n<p>(2)没话说,明天就汇操了</p>\n<p>(3)同一</p>\n<p>2025.9.7错误</p>\n<p>(1)感觉自己的所作所为伤害到妈妈的心了(周日晚上来取衣服的时候,她会不会以为是我不想和她在一起,或者把她赶走)有点后悔,<strong>但是我不知道怎么做</strong>,很难受</p>";
const frontmatter = { "title": "日省小笺🎯", "published": "2025-08-25T00:00:00.000Z", "description": "用来记录我所犯的错误", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 2, "words": 324, "excerpt": "用来记录我所犯的错误:" };
const file = "D:/github-git/fuwari-blog/src/content/spec/page-1770175976.596352.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
