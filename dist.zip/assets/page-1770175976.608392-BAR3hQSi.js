import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>个人介绍</p>\n<p><strong>我的名字是黄浩景,英文缩写hhj (Huang Haojing)****-爱好听音乐,写文章,看散文目前年龄13 初中 来自福建你们可以叫我 hhj</strong></p>\n<p>梦想与目标</p>\n<p><strong>我的梦想并不伟大,仅仅是成为一个老师,又或者是当大厂的996</strong>目前目标是初二入团~<strong>我的目标只有一个,学习学习再学习,努力向梦想前进</strong>!</p>\n<p>代表作品</p>";
const frontmatter = { "title": "关于", "published": "2025-10-01T00:00:00.000Z", "description": "个人介绍 我的名字是黄浩景,英文缩写hhj (Huang Haojing)-爱好听音乐,写文章,看散文目前年龄13 初中 来自福建你们可以叫我 hhj 梦想与目标 我的梦想并不伟大,", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 1, "words": 114, "excerpt": "个人介绍" };
const file = "D:/github-git/fuwari-blog/src/content/spec/page-1770175976.608392.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
