import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>时光匆匆,时间一去不复返</p>\n<p>盛年不重来，一日难再晨。及时宜自勉，岁月不待人。——</p>\n<p>从一年级<strong>小不点</strong>成长为六年级的<strong>高个子</strong></p>\n<p>从六年级的开始到六年级的结束在校时间也才200多天</p>\n<p>小学六年在校时间也才1825天,可谓是极其匆匆忙忙</p>\n<p>来不及怀念小学,我马上就要迈入初中的怀抱,细细想来小学占了人生中6%的时间,在这6%的时间里,在这所鸟语花香的学校里,我最感谢的就是老师,我最敬重也是老师,老师的细心栽培犹如春雨润物细无声,老师用他正确的三观指引了我前方的一片未知的道路,可谓是我心中的一束光,我人生中一束重要的光</p>\n<p>人生中一束重要的光</p>\n<p>“随风潜入夜,润物细无声”</p>\n<p><strong>重要,无需多言</strong></p>\n<p>重要的光,在<strong>漫长的岁月</strong>中体现</p>\n<p>在<strong>老师</strong>的悉心栽培下,<strong>我</strong>创作出了印象十分深刻的的<strong>一幅画</strong></p>\n<p>那一天是<strong>极其糟糕</strong>的,语文数学双从打击下,美术变得不再有”<strong>美</strong>”感</p>\n<p><strong>听</strong>之乏味,<strong>看</strong>之无聊,<strong>学</strong>之乏力. 读书有三道,心到,口到,眼到,我那是<strong>都没到</strong></p>\n<p>老师巡逻时的<strong>压迫感</strong>,使人都不受控制<strong>发抖</strong>,密不透风的教室<strong>令人窒息</strong>,墙上时钟的无比规范滴答声<strong>使人烦躁</strong></p>\n<p>老师走的越来越近,<strong>我</strong>向黑板上投影的样本看就越频繁</p>\n<p>老师走了下来</p>\n<p>手指着我的画本,<strong>两三句</strong>把我不会的地方<strong>讲明白了</strong>,随即又走向另一个的学生,重复着刚才教我的步骤,耐心又细心的把学生们不会的难点转换成一个一个小巧的知识点,巧妙地把<strong>难题</strong>转化为了简单的”<strong>加减法</strong>”</p>\n<p>我心里是<strong>佩服</strong>的,这位老师<strong>巧妙地</strong>把难点转化为简单的知识点给予了一群”<strong>小蜜蜂</strong>”</p>\n<p>就像春雨,在来年的春天润物细无声,冬天万物凋零,春天的雨又把生命力与顽强的精神带了回来</p>\n<p>小学六年,同学也是非常非常重要的,小学的同学幼稚,但是带着一股天真的<strong>快乐</strong>,天真的<strong>童趣</strong></p>\n<p>毕业前后的同学</p>\n<p>“我们毕业了!”</p>\n<p>“耶!”</p>\n<p><strong>安静---</strong></p>\n<p><strong>安静---</strong>---</p>\n<p>我有一些小尴尬,眼睛瞟向天空</p>\n<p><strong>“小漳州的黄昏真好看”</strong></p>\n<p>“喂喂!签一下名”</p>\n<p>手上多了一根签字笔,我又坐在了教室里</p>\n<p>洋洋洒洒签下我名字之后,我看向签名的地方</p>\n<p>望着自由的小男孩,望着他自由的脸庞,望着他被风吹起的衣服,想起了朋友,想起了小学六年陪伴我的同学</p>\n<p>ta有青春的影子,有我们小学六年的影子</p>\n<p>ta在我眼里,是许许多多的人组合在一起,聪明善良的xxx,搞笑担当xxx,以及沉重稳重的我,形形色色的人组成了ta</p>\n<p>ta变成了一张照片</p>\n<p>ta变成了在记忆残留中的一张不起眼的小照片</p>\n<p>ta如同上面的标语,是纯真的记忆,是忘却不了的回忆,是青春的代表,是同学间的体现</p>\n<p>ta在数字世界永存</p>\n<p>ta在精神层面上永恒</p>\n<p>ta不可被描述,可是处处存在,永远存在</p>\n<p><strong>…</strong></p>\n<p>安静之后</p>\n<p>是十足的热闹,狂欢</p>\n<p>“拜拜”</p>\n<p>“拜拜”</p>\n<p>“拜拜”</p>\n<p>在一声一声”拜拜”中,这一场狂欢终于拉下了帷幕</p>\n<p>一样的平静</p>\n<p>没有想象中的哭泣送别,热烈拥抱,一切都是如此的平静…</p>";
const frontmatter = { "title": "我们毕业了!😶‍🌫️", "published": "2025-05-29T00:00:00.000Z", "description": "时光匆匆,时间一去不复返 盛年不重来，一日难再晨。及时宜自勉，岁月不待人。—— 从一年级小不点成长为六年级的高个子 从六年级的开始到六年级的结束在校时间也才200多天 小学六年在校时间也才1825天,...", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 5, "words": 983, "excerpt": "时光匆匆,时间一去不复返" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.915391.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
