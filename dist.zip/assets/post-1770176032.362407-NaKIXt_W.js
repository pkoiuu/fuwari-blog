import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>先说近的再说远的🎇</p>\n<p>2025.11.6</p>\n<p>网站logo全面换新[]<del>(￣▽￣)</del>*  [虽然是AI生成]</p>\n<p><img src="/wp-content/uploads/2025/11/1763272770-20251116055930670526.webp" alt=""></p>\n<p><img src="/wp-content/uploads/2025/11/1763272783-20251116055943683689.webp" alt="">{“AIGC”:{“Label”:“1”,“ContentProducer”:“doubao”,“ProduceID”:“349e809cc59c4e82919371173a601b88”,“ReservedCode1”:"",“ContentPropagator”:"",“PropagateID”:"",“ReservedCode2”:""}}</p>\n<p><img src="/wp-content/uploads/2025/11/1763272798-20251116055958860838.webp" alt=""></p>\n<p><img src="/wp-content/uploads/2025/11/1763272825-20251116060025293401.webp" alt="">{“AIGC”:{“Label”:“1”,“ContentProducer”:“doubao”,“ProduceID”:“29c4d76886b640dfb1414b28be61f681”,“ReservedCode1”:"",“ContentPropagator”:"",“PropagateID”:"",“ReservedCode2”:""}}</p>\n<p><img src="/wp-content/uploads/2025/11/1763272831-20251116060031567605.webp" alt=""></p>\n<p>2025.xx.xx</p>\n<p><strong>cdn优化,现在加载时间一般在三秒以内,如果运气好一秒以内就行了</strong></p>\n<p><img src="/wp-content/uploads/2025/11/1763272937-20251116060217077260.webp" alt=""></p>\n<p>**网站安全性大幅度增加[主要依靠cdn自带的防护] **</p>\n<p>现在的网络攻击好吓人,我这一个小站点也天天被恶意爆破…有时间我再专门写一篇文章</p>\n<p><img src="/wp-content/uploads/2025/11/1763273105-20251116060505342149.webp" alt=""></p>';
const frontmatter = { "title": "从上次更新至本次更新所有内容🎄", "published": "2025-11-16T00:00:00.000Z", "description": '先说近的再说远的🎇\n\n2025.11.6\n\n网站logo全面换新[]~(￣▽￣)~*  [虽然是AI生成]\n\n{"AIGC":{"Label":"1","ContentPr"\n', "tags": ["更新日志"], "category": "更新日志", "draft": false, "minutes": 1, "words": 110, "excerpt": "先说近的再说远的🎇" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770176032.362407.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
