import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => `<section><h1 id="about个人介绍">About(个人介绍)<a class="anchor" href="#about个人介绍"><span class="anchor-icon" data-pagefind-ignore="">#</span></a></h1><p>**我的名字是黄浩景,英文缩写hhj (Huang Haojing)****-爱好听音乐,写文章,看散文目前年龄13 初中 来自福建你们可以叫我 hhj</p><p>梦想与目标</p><p><strong>我的梦想并不伟大,仅仅是成为一个老师,又或者是当大厂的996</strong>目前目标是初二入团~<strong>我的目标只有一个,学习学习再学习,努力向梦想前进</strong>!</p><p>tg频道:<a href="https://t.me/jinghao_blog">https://t.me/jinghao_blog</a></p><p>作者tg:<a href="https://t.me/haohaojing">https://t.me/haohaojing</a></p><p><strong>最推荐的(安全私密)</strong></p><p>电脑访问<a href="https://chat.hhj520.top/">https://chat.hhj520.top/</a></p><p>注册一下就可以了,默认进入两个大群艾特管理员-𝐂𝐨𝐤𝐞可乐.</p><p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755933631-20250823072031387079.webp" alt="图片"></p><p><strong>(第二推荐)没有电脑免注册</strong></p><p>如果没有电脑的注册不了账号,那么就通过<a href="https://mm.hhj520.top/widget.html?host=1">https://mm.hhj520.top/widget.html?host=1</a></p><p>进行联系<strong>免注册,需要临时联系选他</strong>(我可能不会及时回复)</p><p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755932124-20250823065524058459.webp" alt="图片"></p><p><strong>其他推荐</strong></p><p>你们可能很好奇,为什么第一推荐和第二推荐没有常见的<strong>微信, QQ</strong>之类的</p><p>那是因为<strong>常规的软件有封号</strong>的危险,而且扩展低,我自己需要一个高扩展的,可以自我管理的聊天软件</p><p>而且大众聊天软件不安全,没有消息保护,自己部署的有消息保护,而且自己部署可以实现永久保存聊天记录/文件,所以我自己是非常非常不愿意使用微信QQ之类的聊天软件,但是微信QQ实在是使用人数太多了,平时还可以支付,所以目前我没有完全退出微信,QQ</p><p><strong>我的微信号<hhjhjlq></hhjhjlq></strong></p><p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755932639-20250823070359694974.webp" alt="图片"></p><p>QQ</p><p>[点击加qq](<a href="https://qm.qq.com/cgi-bin/qm/qr?k=Ly2d8IoU43uMhGFJemOiox69Is4R7Aeu">https://qm.qq.com/cgi-bin/qm/qr?k=Ly2d8IoU43uMhGFJemOiox69Is4R7Aeu</a>” target=“_blank” rel=“noreferrer noopener)</p><p>我的邮箱:</p><p><a href="mailto:hhj@ts.hhj520.top">hhj@ts.hhj520.top</a></p><p><a href="mailto:sy111125@outlook.com">sy111125@outlook.com</a></p><a id="GCnm6zfj-card" class="card-github fetch-waiting no-styling" href="https://github.com/pkoiuu/fuwari-blog" target="_blank" repo="pkoiuu/fuwari-blog"><div class="gc-titlebar"><div class="gc-titlebar-left"><div class="gc-owner"><div id="GCnm6zfj-avatar" class="gc-avatar"></div><div class="gc-user">pkoiuu</div></div><div class="gc-divider">/</div><div class="gc-repo">fuwari-blog</div></div><div class="github-logo"></div></div><div id="GCnm6zfj-description" class="gc-description">Waiting for api.github.com...</div><div class="gc-infobar"><div id="GCnm6zfj-stars" class="gc-stars">00K</div><div id="GCnm6zfj-forks" class="gc-forks">0K</div><div id="GCnm6zfj-license" class="gc-license">0K</div><span id="GCnm6zfj-language" class="gc-language">Waiting...</span></div><script id="GCnm6zfj-script" type="text/javascript" defer>
      fetch('https://api.github.com/repos/pkoiuu/fuwari-blog', { referrerPolicy: "no-referrer" }).then(response => response.json()).then(data => {
        document.getElementById('GCnm6zfj-description').innerText = data.description?.replace(/:[a-zA-Z0-9_]+:/g, '') || "Description not set";
        document.getElementById('GCnm6zfj-language').innerText = data.language;
        document.getElementById('GCnm6zfj-forks').innerText = Intl.NumberFormat('en-us', { notation: "compact", maximumFractionDigits: 1 }).format(data.forks).replaceAll(" ", '');
        document.getElementById('GCnm6zfj-stars').innerText = Intl.NumberFormat('en-us', { notation: "compact", maximumFractionDigits: 1 }).format(data.stargazers_count).replaceAll(" ", '');
        const avatarEl = document.getElementById('GCnm6zfj-avatar');
        avatarEl.style.backgroundImage = 'url(' + data.owner.avatar_url + ')';
        avatarEl.style.backgroundColor = 'transparent';
        document.getElementById('GCnm6zfj-license').innerText = data.license?.spdx_id || "no-license";
        document.getElementById('GCnm6zfj-card').classList.remove("fetch-waiting");
        console.log("[GITHUB-CARD] Loaded card for pkoiuu/fuwari-blog | GCnm6zfj.")
      }).catch(err => {
        const c = document.getElementById('GCnm6zfj-card');
        c?.classList.add("fetch-error");
        console.warn("[GITHUB-CARD] (Error) Loading card for pkoiuu/fuwari-blog | GCnm6zfj.")
      })
    <\/script></a></section>`;
const frontmatter = { "title": "About", "published": "2024-01-01T00:00:00.000Z", "description": "关于网站", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 2, "words": 417, "excerpt": "**我的名字是黄浩景,英文缩写hhj (Huang Haojing)****-爱好听音乐,写文章,看散文目前年龄13 初中 来自福建你们可以叫我 hhj" };
const file = "D:/github-git/fuwari-blog/src/content/spec/about.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
