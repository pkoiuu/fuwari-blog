import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>啊啊啊！半天妖青花椒烤鱼真的好吃到要命！！</p>\n<p>我甚至怀疑他往锅底下了一些什么不可描述的药，太让人上瘾了吧！</p>\n<p>爱吃！想吃！上瘾！太太太太太太太太好吃了！鱼肉嫩滑，细腻，肥美，刺又少！强烈推荐大家去吃半天妖烤鱼！</p>\n<p>我是在漳州市沃尔玛4楼吃的，超级超级无敌好吃！回购了好几次了！</p>";
const frontmatter = { "title": "极品半天妖烤鱼！٩(•̤̀ᵕ•̤́๑)ᵒᵏᵎᵎᵎᵎ", "published": "2025-05-01T00:00:00.000Z", "description": "啊啊啊！半天妖青花椒烤鱼真的好吃到要命！！ 我甚至怀疑他往锅底下了一些什么不可描述的药，太让人上瘾了吧！ 爱吃！想吃！上瘾！太太太太太太太太好吃了！鱼肉嫩滑，细腻，肥美，刺又少！强烈推荐大家去吃半天妖...", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 1, "words": 115, "excerpt": "啊啊啊！半天妖青花椒烤鱼真的好吃到要命！！" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.904408.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
