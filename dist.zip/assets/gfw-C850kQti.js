import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>免责说明:</p>\n<p>本篇文章”关于 GFW(长城防火墙)“是站在个人角度发表,并不代表所有人,出了事与本文无任何关系</p>\n<p>正文:</p>\n<p>中国的GFW就是一个巨大的长城,把中国网络变成了一个”封闭的皇宫”<strong>非常的不人道</strong></p>\n<p>中国的老百姓,看到的是虚假的,错误的,不真实的</p>\n<p>中国的老百姓常把<strong>中国</strong>说成世界第一,可是世界上公认世界第一是美国,全世界经济第一还是美国,中国呢?中国厉害,但,不是第一</p>\n<p><strong>中国老百姓为什么总把中国认为是世界第一呢?</strong></p>\n<p>正是因为有”长城”把中国包围,成了一个”封闭的皇宫”老百姓看不到<strong>真实</strong>的消息,这种做法,实在太不人道了,老百姓有权利看到**“真相”**</p>\n<p>引用张维为教授解说防火墙时说的话:“1.西方软实力现在比我国强（没有防火墙是不行的）……</p>\n<p>2.巨大经济利益…(因为)谷歌带来这么多的垄断问题……”（2）</p>\n<p>在早期我国互联网中的舆论环境如果没有GFW，就会造成许多社会管理难题，利大于弊！</p>\n<p>//（可以在评论区里适当讨论，别太兴奋了）</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755721671-20250820202751410315.webp" alt="图片"></p>';
const frontmatter = { "title": "关于 GFW(长城防火墙)", "published": "2025-08-20T00:00:00.000Z", "description": '免责说明: 本篇文章"关于 GFW(长城防火墙)"是站在个人角度发表,并不代表所有人,出了事与本文无任何关系 正文: 中国的GFW就是一个巨大的长城,把中国网络变成了一个"封闭的"\n', "tags": ["gwf", "中国", "人道主义", "长城", "防护", "防火墙"], "category": "灵感", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755721671-20250820202751410315.webp", "minutes": 2, "words": 348, "excerpt": "免责说明:" };
const file = "D:/github-git/fuwari-blog/src/content/posts/gfw.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
