import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>增加</p>\n<ol>\n<li><strong>新增加</strong>页面<a href="https://hhj520.top/%e6%97%a5%e5%b8%b8%f0%9f%95%b6%ef%b8%8f/">生活琐记</a>(记录日常生活)</li>\n</ol>\n<p>2.<strong>新增加</strong>页面<a href="https://hhj520.top/%e6%97%a5%e7%9c%81%e5%b0%8f%e7%ac%ba%f0%9f%8e%af/">日省小笺🎯</a>(反思自我)</p>\n<p>3.<strong>新增加</strong><a href="https://hhj520.top/%e8%81%94%e7%b3%bb%e6%96%b9%e5%bc%8f/">联系方式</a>(方便联系)</p>\n<p>删除</p>\n<ol>\n<li>音乐播放器删除(拖慢速度)</li>\n</ol>\n<p>优化</p>\n<p>1.优化网站体积增加速度</p>\n<p>2.页脚在保持样式不变的情况下大幅度优化了</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/09/1757086299-20250905153139536947.webp" alt="图片"></p>';
const frontmatter = { "title": "博客更新日志2025.9.5", "published": "2025-09-05T00:00:00.000Z", "description": "增加 1. 新增加页面生活琐记(记录日常生活) 2.新增加页面日省小笺🎯(反思自我) 3.新增加联系方式(方便联系) 删除 1. 音乐播放器删除(拖慢速度) 优化 1.优化网站体积增加速度 2.页脚在保持样式不变的情况下大幅度优化了\n", "tags": ["更新日志"], "category": "更新日志", "draft": false, "minutes": 1, "words": 92, "excerpt": "增加" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-09-05.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
