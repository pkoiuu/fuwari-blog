import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>青春无价,在少年时,我们应该倍加珍惜青春,好好享受青春,好好的体会青春,青春不可再来,过去了就是过去了,不可挽回</p>\n<p>前言</p>\n<p>人生中<strong>第一次正规</strong>的考试</p>\n<p>一楼的教室比我们三楼教室<strong>明亮</strong>多了,也<strong>高了</strong>不少,所有的草稿纸都是由<strong>教师发的</strong>,好正规</p>\n<p><strong>书包还要放在教室外面,<strong>英语听力是通过</strong>广播播放</strong>的,<strong>提前一天</strong>进行<strong>试听</strong></p>\n<p>来说说感受</p>\n<p><strong>1.<strong>考试的前一天</strong>根本睡不着</strong>,一直想<strong>复习</strong>,数学的<strong>几何题</strong>不知道复习多少遍了,语文的<strong>课外知识点</strong>不知道背了多少写了多少,结果一进—<strong>没忘记</strong>!  但是拿到卷子<strong>傻眼</strong>,复习的一道题目都没有,全是简单题,<strong>甚至</strong>连背诵默写都不考<strong>课外知识,<strong>数学</strong>甚至</strong>不考<strong>几何题</strong>,难度简直是简简单单</p>\n<p><strong>2.语文</strong>考试时,在我那一个座位上有<strong>超级多蚊子</strong>,被蚊子咬的我,<strong>是抓耳挠腮</strong>,<strong>注意力集中不了一点</strong>,越写越乱<strong>越写越乱</strong>,没节奏感了,看到<strong>作文</strong>时<strong>傻眼</strong>了,一个<strong>题材</strong>都<strong>不是我所预料</strong>的,背的<strong>清华附中</strong>优秀题目/作文,一个没有考,反而是选题,一个是<strong>哪吒精神</strong>,另一个是<strong>科技类</strong>的 我选了<strong>第二个</strong>,还挺好写的,写到最后的最后,被那一只死蚊子咬得<strong>心浮气躁</strong>的,好在是写完了试卷</p>\n<p><strong>3.数学</strong>考试,语文考试完成之后休息五分钟,直接考数学(其实还挺好)重新进入到拿到答题卡,时间都比休息时间还长呢…拿到数学试卷,看了一圈<strong>没有什么难点</strong>(我复习的几何题都没考!)心情一下子就愉快了许多,观察了一下<strong>分值分布情况</strong>,应用题>填空题>计算题>选择题,我脑袋中意识到<strong>计算题分值很高,<strong>而且只有四道简单题,需要牢牢把握住机会,比选择题好拿多了,做拿着草稿纸计算了两到三遍,<strong>确认无误</strong>才把填空做了,一空两分啊!!!!!!!!!还有一道小陷阱题,还好</strong>巧妙地化解</strong>,选择题没有什么难度,后面的应用题基本都是说道理,我觉得这分应该得到了,倒数第二题,其实我不太确定我做的是错的还是对的,答案是对的过程可能错了,不过也才几分而已,<strong>都可以达到老师给我的目标</strong>awa</p>\n<p>4.综合考试,因为<strong>漳州市统考</strong>的原因,英语一百分,被分成了英语四十分,科学三十分,道德与法治三十分<strong>40%,30%30%</strong>,英语我<strong>本来就不太好</strong>,上一次模拟考了20分,道德25分,科学29分,总分才74…崩溃了,科学最后一题还有一个画图,感觉应该是<strong>拿不到分</strong>,还有好几题都是课外的,感觉就像是把语文数学的难度全加在了科学上,不知道编辑组怎么想的…<strong>甚至科学试卷还考了一个一个数学的分段计费</strong>…应该把综合出卷老师<strong>打下冷宫!</strong></p>\n<p>总结</p>\n<p><strong>无论考的怎么样,努力了就行,为小学生活慢慢的画上一个完美句号,加油吧奋斗者!</strong></p>\n<p>英文版(ai)</p>\n<p>Youth is priceless. In our youth, we should cherish it more, enjoy it well, and truly experience it. Youth cannot be repeated; once it passes, it is gone and irreparable.</p>";
const frontmatter = { "title": "我们毕业考了!", "published": "2025-05-15T00:00:00.000Z", "description": "青春无价,在少年时,我们应该倍加珍惜青春,好好享受青春,好好的体会青春,青春不可再来,过去了就是过去了,不可挽回 前言 人生中第一次正规的考试 一楼的教室比我们三楼教室明亮多了,也高了不少,所有的草稿...", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 5, "words": 917, "excerpt": "青春无价,在少年时,我们应该倍加珍惜青春,好好享受青春,好好的体会青春,青春不可再来,过去了就是过去了,不可挽回" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.912998.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
