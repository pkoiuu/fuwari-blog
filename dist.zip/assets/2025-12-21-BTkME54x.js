import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>一转眼又到年末了,2025年对我来说<strong>非常值得纪念</strong></p>\n<p>前半年小学毕业,后半年踏上初中的旅程,历经的分别,又认识了新的同学</p>\n<p>冬至怎么能不来一顿丰盛的大餐呢?</p>\n<p>今年冬至母亲准备了  汤圆,水饺,贵州火锅,酱油鱼,甘蔗,好吃得很耶!</p>\n<p>汤圆是芝麻汤圆甜滋滋，水饺<strong>皮薄馅大</strong>，贵州火锅香喷喷，蘸料还是我最爱的芝麻酱！酱油鱼也不用多说了，浓郁的葱香混着咸香，那滋味～</p>\n<p>今年母亲还喜欢上了种花,种菜,别有一番闲情雅致</p>\n<p>别说种的还挺不错!再有十几天菜应该要收获了</p>\n<p>今年的冬至挺精彩的..但是失去的青春一去不复返了</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766322150-20251221130230854748.webp" alt="图片"></p>';
const frontmatter = { "title": "2025.12.21-冬至", "published": "2025-12-21T00:00:00.000Z", "description": "一转眼又到年末了,2025年对我来说非常值得纪念 前半年小学毕业,后半年踏上初中的旅程,历经的分别,又认识了新的同学 冬至怎么能不来一顿丰盛的大餐呢? 今年冬至母亲准备了 汤圆,水饺,贵州火锅,酱油鱼,甘蔗,好吃得很耶!\n", "tags": ["冬至", "妈妈", "美食", "随笔"], "category": "童年往事", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766322150-20251221130230854748.webp", "minutes": 1, "words": 212, "excerpt": "一转眼又到年末了,2025年对我来说非常值得纪念" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-12-21.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
