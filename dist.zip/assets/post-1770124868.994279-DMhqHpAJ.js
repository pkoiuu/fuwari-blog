import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>上了初中之后学习的压力如潮水般向我涌来;同班同学的差距,学校的差距,区域的差距一个比一个大,一个个压得我喘不气,心酸和委屈涌上心头,难道就要因此而堕落?难道我注定是这样子的命?</p>\n<p>仿佛是班主任与大家心有灵犀,课后延时整整一个小时全部拿来给我们放松;积分奖励,心理小游戏(节奏运动,萝卜蹲…)我好喜欢这氛围,青春的活力一下子就涌了上来,带走所有的委屈与不甘,指引了我前进的道路</p>\n<p><strong>后来老师说的话…</strong></p>\n<p>“你们现在的目标是努努力进科创班,这次考不好也没关系,下次接着努力就行”</p>\n<p>“你在游戏的时间花的只要比学习的时间还多,你的成绩肯定上不去”</p>\n<p>期中的差距让我意识到了人无完人,天外有天;我们应该努力学习积极向上,争取做新时代的好少年!</p>";
const frontmatter = { "title": "期中差距有感一言🎯", "published": "2025-10-17T00:00:00.000Z", "description": "上了初中之后学习的压力如潮水般向我涌来;同班同学的差距,学校的差距,区域的差距一个比一个大,一个个压得我喘不气,心酸和委屈涌上心头,难道就要因此而堕落?难道我注定是这样子的命? 仿佛是班主任与大家心有...", "tags": ["Uncategorized"], "category": "灵感", "draft": false, "minutes": 1, "words": 279, "excerpt": "上了初中之后学习的压力如潮水般向我涌来;同班同学的差距,学校的差距,区域的差距一个比一个大,一个个压得我喘不气,心酸和委屈涌上心头,难道就要因此而堕落?难道我注定是这样子的命?" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.994279.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
