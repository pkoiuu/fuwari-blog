import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<ol>\n<li><strong>弹窗更新,对比原来字体更大 , 新增加朋友-<a href="https://mgxhz.ct.ws/">mgxhz.ct</a> 友情链接,新增加备案号 , 左下角按钮变成查看所有项目</strong></li>\n</ol>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1756015703-20250824060823284702.webp" alt="图片"></p>\n<p><strong>2. 顶部增加分类,优化外观</strong></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1756015753-20250824060913081537.webp" alt="图片"></p>\n<p><strong>3. 页脚新增友情链接</strong></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1756015809-20250824061009624164.webp" alt="图片"></p>\n<p><strong>4. 文本复制颜色从原本的粉红色变成了浅灰色+有透明度的蓝色(原本的实在太刺眼了)</strong></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1756015932-20250824061212234512.webp" alt="图片"></p>';
const frontmatter = { "title": "博客更新日志2025.8.24", "published": "2025-08-24T00:00:00.000Z", "description": "1. 弹窗更新,对比原来字体更大 , 新增加朋友-mgxhz.ct 友情链接,新增加备案号 , 左下角按钮变成查看所有项目 2. 顶部增加分类,优化外观 3. 页脚新增友情链接 4. 文本复制颜色从原本的粉红色变成了浅灰色+有透明度的蓝色\n", "tags": ["8.24", "博客更新", "博客更新日志", "更新日志"], "category": "更新日志", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1756015809-20250824061009624164.webp", "minutes": 1, "words": 105, "excerpt": "图片" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-08-24.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
