import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p><em>秋季的风,还夹带着夏季的余温,悠悠的</em></p>\n<p>夕阳,火烧云,小贩的叫卖声交织在一起,我坐在父亲的小车上,呆呆的望着来来往往的人群,这些人有的是晚自习结束,准备回家洗洗睡了,有的是下班了,就是迫不及待的回家睡大觉,还有的是准备出去和兄弟吃一顿烧烤喝一点小酒,有说有笑,三五成群勾肩搭背走在一起,像极了电视剧中大结局了主角团庆祝胜利的样子.</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/09/1758434546-20250921060226666058.webp" alt="图片"></p>\n<p><strong>而我不同</strong>,当他们沉浸在凡间的快乐,悠闲时,我已超脱凡俗,达到了一个更高渺的境界- 发呆</p>\n<p>一整天的疲劳,仿佛是<strong>千斤顶</strong>,压得我喘不过气,我感觉到我的大脑停止运转,浑身酸痛的,就像是小说中魂飞魄散,前面的车尾灯散发着令人不适的红色,我又想起了那一次厦门大堵车,下车之后目之所及被染上了一层红色,我讨厌凡间的繁琐,我讨厌凡间令人作呕的规矩,我讨厌凡间,却逃脱不出凡间,我讨厌凡间,却还是会被凡间<strong>热情与向往治愈</strong>,回顾今天的点点滴滴,我疲倦的内心好了许多</p>\n<p>搬家之前我心有不舍,但是明白这是必然,在这之前我已经搬了三次家了,每一次我都浑身疲软,彻底榨干了自己,这一次也不例外,我与我的父亲背着十几斤的货物来来回回走了六七遍,重复而枯燥,拿下-放车上-开车走-上楼,还没来得及整理,马上进入下一轮,我心里苦啊,难受啊, 车座的想把隔夜饭都吐出来,可是到了最后看着自己布置的小家,成就感还是满满,那一刻我好像都不累了罢</p>\n<p>坐在车上望着夕阳,生活继续走了下去</p>';
const frontmatter = { "title": "随笔-搬家", "published": "2025-09-21T00:00:00.000Z", "description": "秋季的风,还夹带着夏季的余温,悠悠的 夕阳,火烧云,小贩的叫卖声交织在一起,我坐在父亲的小车上,呆呆的望着来来往往的人群,这些人有的是晚自习结束,准备回家洗洗睡了,有的是下班了,就是迫不及待的回家睡大觉\n", "tags": ["搬家", "随笔"], "category": "灵感", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/09/1758434546-20250921060226666058.webp", "minutes": 3, "words": 522, "excerpt": "秋季的风,还夹带着夏季的余温,悠悠的" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-09-21.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
