import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>前言:</p>\n<p>心血来潮,有了自己的VPS,那就要把它的价值发挥到极致,搭建github镜像站,正好解决了面向搭建github镜像站大众的不怎么流畅的问题,为我以后查看代码/下载资源/分享链接,提供了莫大的帮助,本期教程我会向大家介绍如何搭建github镜像站,以及过程遇到的问题,并且解决hhh</p>\n<p>已知问题:</p>\n<p>不可以登录注册</p>\n<p>下载资源显示不全</p>\n<p>搭建:</p>\n<p>首先我们先进入<a href="https://www.rainyun.com/520bh_">雨云官网</a>，会出现以下界面</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/05/1754062062-9a5eab80ffbcb1f4482acef4f2326bb7-scaled.png" alt="图片"></p>\n<p>我们点击右上角的登录与注册填写信息完成注册，然后登陆 PS：本人优惠码：520bh_  新用户填写赠服务器首月半折优惠卷</p>\n<p><strong>购买云服务器,安装宝塔,过程就不演示了</strong></p>\n<p>如果已经有了vps可以省略这一步</p>\n<p>点击网站</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1754719921-20250809061201451303.png" alt="图片"></p>\n<p>添加一个项目,千万不要选择反向代理,造成问题</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1754719991-20250809061311072231.png" alt="图片"></p>\n<p>默认就行,然后点击反向代理</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1754720039-20250809061359531440.png" alt="图片"></p>\n<p>像我这样子填就行</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1754720076-20250809061436986572.png" alt="图片"></p>\n<p>这样子就差不多完成了,</p>';
const frontmatter = { "title": "搭建github镜像站教程", "published": "2025-08-09T00:00:00.000Z", "description": "前言: 心血来潮,有了自己的VPS,那就要把它的价值发挥到极致,搭建github镜像站,正好解决了面向搭建github镜像站大众的不怎么流畅的问题,为我以后查看代码/下载资源/分享链接,提供了莫大的帮助\n", "tags": ["Uncategorized"], "category": "所有", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/05/1754062062-9a5eab80ffbcb1f4482acef4f2326bb7-scaled.png", "minutes": 1, "words": 294, "excerpt": "前言:" };
const file = "D:/github-git/fuwari-blog/src/content/posts/github.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
