import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>我的博客大约是在去年的七月份完成,其间进行了很多次更新,但是我硬是没想出来发布日志…(水文)</p>\n<p>哎有点懊悔,多次更新都没有发布文章,别人根本不知道我为了这一个博客付出了多少努力(炫耀)</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755830213-20250822023653943849.webp" alt="图片"></p>\n<p>接下来说正事:</p>\n<p>1.新增加<strong>音乐播放器</strong>,全局播放 ***(wp音乐播放器插件挺难找的,博客发布一年了才找到合适的)***补充说明:拖慢页面加载速度现在已经取消</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755830663-20250822024423857095.webp" alt="图片"></p>\n<p>2.图标换成圆形,优化外观</p>\n<p>3.优化性能 <em><strong>(wp非母语en加载速度会变慢一点,使用wp官方的插件”性能实验室”里面的Performant Translations 使 WordPress 的国际化/本地化比以往任何时候都快,速度真的上来了特别是后台!!!)</strong></em></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755830621-20250822024341565620.webp" alt="图片"></p>\n<p>如果有人对性能优化比较感兴趣,我可以出一期专门讲优化的 嘿嘿嘿</p>\n<p>本篇文章到此结束了,这就是本次更新的所有内容</p>\n<p>-hhj</p>\n<p>-8.22</p>';
const frontmatter = { "title": "博客更新日志2025.8.22", "published": "2025-08-22T00:00:00.000Z", "description": "我的博客大约是在去年的七月份完成,其间进行了很多次更新,但是我硬是没想出来发布日志...(水文) 哎有点懊悔,多次更新都没有发布文章,别人根本不知道我为了这一个博客付出了多少努力(炫耀)\n", "tags": ["blog", "wp", "博客优化", "性能优化", "音乐播放器"], "category": "更新日志", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755830663-20250822024423857095.webp", "minutes": 1, "words": 281, "excerpt": "我的博客大约是在去年的七月份完成,其间进行了很多次更新,但是我硬是没想出来发布日志…(水文)" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-08-22.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
