import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>前几天,我在这一个blog主题的作者的博客上看到了一句</p>\n<p>“留存此篇文章不是因为懒，这篇文章见证了我博客搭建成功的时间(≧▽≦)”</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755831132-20250822025212959108.webp" alt="图片"></p>\n<p>我觉得这一句写的非常的好!</p>\n<p>说实话写这一篇Hello world的时候我不知道为什么所有cms默认就有Hello world,我觉得好烦人…</p>\n<p>现在看见他的这一句话,顿时<strong>豁然开朗</strong>,原来Hello world | 你好,世界 存在的意义是纪念”博客搭建成功的时间”</p>\n<p>这一篇文章是按照我当时自己对Hello world的理解写的,我还没有完全理解它的意义,哎算了算了…现在想一想当时的错误挺有趣,有<strong>纪念意义</strong>,所以就在文章后面增加了一段”感慨”也就是本文章,欢迎大家来访问</p>\n<p><a href="https://hhj520.top/hello-world-%e4%bd%a0%e5%a5%bd%e4%b8%96%e7%95%8c/">原本文章</a></p>\n<p><a href="https://blog.ixk.me/post/hello-world">blog主题作者Hello word文章</a></p>\n<p>hhj</p>\n<p>8.22</p>';
const frontmatter = { "title": "关于Hello world | 你好,世界", "published": "2025-08-22T00:00:00.000Z", "description": '前几天,我在这一个blog主题的作者的博客上看到了一句 "留存此篇文章不是因为懒，这篇文章见证了我博客搭建成功的时间(≧▽≦)" 我觉得这一句写的非常的好!  说实话写这一篇Hello world的时候我不知道为什么所有cms默认就有Hello world,我觉得好烦人...\n', "tags": ["Hello world", "你好世界", "关于"], "category": "灵感", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755831132-20250822025212959108.webp", "minutes": 1, "words": 247, "excerpt": "前几天,我在这一个blog主题的作者的博客上看到了一句" };
const file = "D:/github-git/fuwari-blog/src/content/posts/hello-world.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
