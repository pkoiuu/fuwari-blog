import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>过去了一年,我也从一个小学生变成了一位初中生,时间就像那一去不复返的河流,每时每秒都在奔腾不息的游走,我们能做的就只有记录它,享受它,而今年的我做了一次不同的决定</p>\n<p>2025.12.31学校的元旦晚会结束回家吃饭之时一个念头,在我的脑海浮现了出来—以往是在家里过年,如今搬了家旁边就是吾悦广场,恰好吾悦有民众自行组织的跨年活动,干脆直接在吾悦过吧~</p>\n<p>于是:</p>\n<p><a href="https://www.bilibili.com/video/BV11Gv9B2ENY/?share_source=copy_web&#x26;vd_source=fcb8a6420bdf2075bc7ae21ffbb77624">【再见2025-新的一年新的起点!加油努力的少年】</a></p>\n<p>新年快乐!</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/01/1767335651-20260102063411785742-scaled.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/01/1767335663-20260102063423161596.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/01/1767335670-20260102063430175736.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/01/1767335693-20260102063453252437.webp" alt="图片"></p>';
const frontmatter = { "title": "再见2025-第一次放飞气球跨年", "published": "2026-01-01T00:00:00.000Z", "description": "过去了一年,我也从一个小学生变成了一位初中生,时间就像那一去不复返的河流,每时每秒都在奔腾不息的游走,我们能做的就只有记录它,享受它,而今年的我做了一次不同的决定 2025.12.31学校的元旦晚会结束回家吃饭之时一个念头,在我的脑海浮现了出来--以往是在家里过年,如今搬了家旁边就是吾悦广场,恰好吾悦有民众自行组织的跨年活动,干脆直接在吾悦过吧~\n", "tags": ["吾悦", "跨年"], "category": "灵感", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2026/01/1767335663-20260102063423161596.webp", "minutes": 1, "words": 184, "excerpt": "过去了一年,我也从一个小学生变成了一位初中生,时间就像那一去不复返的河流,每时每秒都在奔腾不息的游走,我们能做的就只有记录它,享受它,而今年的我做了一次不同的决定" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2026-01-01.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
