import { c as createComponent, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const $$GlobalStyles = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate``;
}, "D:/github-git/fuwari-blog/src/components/GlobalStyles.astro", void 0);
export {
  $$GlobalStyles as default
};
