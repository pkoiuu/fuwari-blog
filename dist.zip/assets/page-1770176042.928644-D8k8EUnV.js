import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1756627705-20250831080825254828.webp" alt=""></p>\n<p><a href="https://www.bilibili.com/video/av852880575/">https://www.bilibili.com/video/av852880575/</a></p>\n<p><a href="http://music.163.com/#/song?id=186513">http://music.163.com/#/song?id=186513</a></p>\n<p>.video-container {\nposition: relative;\nwidth: 100%;\nmax-width: 1200px; /* 最大宽度限制 <em>/\nmargin: 0 auto; /</em> 居中显示 */\noverflow: hidden;\n}</p>\n<p>.video-container::before {\ncontent: "";\ndisplay: block;\npadding-top: 56.25%; /* 16:9 比例 */\n}</p>\n<p>.video-container iframe {\nposition: absolute;\ntop: 0;\nleft: 0;\nwidth: 100%;\nheight: 100%;\nborder: none;\n}</p>\n<p>/* 针对小屏幕设备的调整 */\n@media (max-width: 768px) {\n.video-container {\npadding-left: 0;\npadding-right: 0;\n}\n}</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1760963232-20251020122712364455.webp" alt=""></p>\n<p>#include &#x3C;stdio.h>\nint main() {\nprintf(“Hello,World!”);\nchar chs[100];\nscanf(“%s”, chs);<br>\nprintf(“%s”, chs);\nreturn 0;\n}运行重置输入</p>\n<p>{% blockquote author, title %}\nquote\n{% endblockquote %}</p>';
const frontmatter = { "title": "测试页面", "published": "2025-10-02T00:00:00.000Z", "description": "https://www.bilibili.com/video/av852880575/ http://music.163.com/#/song?id=186513 [embed] http", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 1, "words": 102, "excerpt": "" };
const file = "D:/github-git/fuwari-blog/src/content/spec/page-1770176042.928644.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
