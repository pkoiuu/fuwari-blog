import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p><a href="https://mgxhz.dpdns.org/">mgxhz的博客</a>\n<img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770216044-processed-48-scaled.webp" alt="mgxhz"></p>';
const frontmatter = { "title": "haohao的朋友们", "published": "2025-10-18T00:00:00.000Z", "description": "友情链接", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 1, "words": 5, "excerpt": "mgxhz的博客\nmgxhz" };
const file = "D:/github-git/fuwari-blog/src/content/spec/friends.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
