import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>国庆快乐呀! 本站在国庆期间进行了这几项更新:</p>\n<p>1.使用<strong>cdn</strong>,大幅度的增加访问速度 (终于终于)</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759552134-20251004042854419126.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759552122-20251004042842741574.webp" alt="图片"></p>\n<p>2.现在支持<strong>注册</strong>了!!!</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759407902-20251002122502993921.webp" alt="图片"></p>\n<p>3.删除站点状态页面,取而代之的是<a href="https://hhj520.top/%e5%85%b3%e4%ba%8e/">关于</a></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759407733-20251002122213490539.webp" alt="图片"></p>\n<p>4.大幅度的减少网站代码</p>\n<p>5.wp更新6.8.3</p>\n<p>6.网站首次访问需要进行人机验证 (防止机器人攻击垃圾评论)</p>';
const frontmatter = { "title": "博客更新日志 2025.10.2", "published": "2025-10-02T00:00:00.000Z", "description": "国庆快乐呀! 本站在国庆期间进行了这几项更新: 1.使用cdn,大幅度的增加访问速度 (终于终于) 2.现在支持注册了!!! 3.删除站点状态页面\n", "tags": ["更新日志"], "category": "更新日志", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759552134-20251004042854419126.webp", "minutes": 1, "words": 111, "excerpt": "国庆快乐呀! 本站在国庆期间进行了这几项更新:" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-10-02.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
