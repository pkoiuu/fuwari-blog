import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>“人在家中坐,震从地上来”快要睡觉了地震突然把我震醒了…特写此文纪念第一次感受到地震</p>\n<p>2025-12-27 23:05:50,中国台湾发生6.5级地震(资料来源:<a href="https://news.ceic.ac.cn/">https://news.ceic.ac.cn/</a>)</p>\n<p>纬度(°)24.66</p>\n<p>经度(°)124.35</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766849084-20251227152444318370.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766849280-20251227152800452119.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766849298-20251227152818801826.webp" alt="图片"></p>';
const frontmatter = { "title": "地震了!台湾6.5级地震,漳州市有明显震感-2025-12-27", "published": "2025-12-27T00:00:00.000Z", "description": '"人在家中坐,震从地上来"快要睡觉了地震突然把我震醒了...特写此文纪念第一次感受到地震 2025-12-27 23:05:50,中国台湾发生6.5级地震\n', "tags": ["Uncategorized"], "category": "青春", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766849084-20251227152444318370.webp", "minutes": 1, "words": 70, "excerpt": "“人在家中坐,震从地上来”快要睡觉了地震突然把我震醒了…特写此文纪念第一次感受到地震" };
const file = "D:/github-git/fuwari-blog/src/content/posts/65-2025-12-27.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
