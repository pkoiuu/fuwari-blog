import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>我的联系方式有很多,我比较推荐的是通过<strong>我自己搭建的聊天软件进行联系(安全私密有保障)</strong></p>\n<p>新增加:</p>\n<p>tg频道:<a href="https://t.me/jinghao_blog">https://t.me/jinghao_blog</a></p>\n<p>作者tg:<a href="https://t.me/haohaojing">https://t.me/haohaojing</a></p>\n<p>欢迎大家来灌水!</p>\n<p><strong>最推荐的(安全私密)</strong></p>\n<p>电脑访问<a href="https://chat.hhj520.top/">https://chat.hhj520.top/</a></p>\n<p>注册一下就可以了,默认进入两个大群艾特管理员-𝐂𝐨𝐤𝐞可乐.</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755933631-20250823072031387079.webp" alt="图片"></p>\n<p><strong>(第二推荐)没有电脑免注册</strong></p>\n<p>如果没有电脑的注册不了账号,那么就通过<a href="https://mm.hhj520.top/widget.html?host=1">https://mm.hhj520.top/widget.html?host=1</a></p>\n<p>进行联系<strong>免注册,需要临时联系选他</strong>(我可能不会及时回复)</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755932124-20250823065524058459.webp" alt="图片"></p>\n<p><strong>其他推荐</strong></p>\n<p>你们可能很好奇,为什么第一推荐和第二推荐没有常见的<strong>微信, QQ</strong>之类的</p>\n<p>那是因为<strong>常规的软件有封号</strong>的危险,而且扩展低,我自己需要一个高扩展的,可以自我管理的聊天软件</p>\n<p>而且大众聊天软件不安全,没有消息保护,自己部署的有消息保护,而且自己部署可以实现永久保存聊天记录/文件,所以我自己是非常非常不愿意使用微信QQ之类的聊天软件,但是微信QQ实在是使用人数太多了,平时还可以支付,所以目前我没有完全退出微信,QQ</p>\n<p><strong>我的微信号<hhjhjlp></hhjhjlp></strong></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755932639-20250823070359694974.webp" alt="图片"></p>\n<p>** QQ**</p>\n<p>[点击加qq](<a href="https://qm.qq.com/cgi-bin/qm/qr?k=Ly2d8IoU43uMhGFJemOiox69Is4R7Aeu">https://qm.qq.com/cgi-bin/qm/qr?k=Ly2d8IoU43uMhGFJemOiox69Is4R7Aeu</a>” target=“_blank” rel=“noreferrer noopener)</p>\n<p>我的邮箱:</p>\n<p><strong><a href="mailto:hhj@ts.hhj520.top">hhj@ts.hhj520.top</a></strong></p>\n<p><a href="mailto:sy111125@outlook.com">sy111125@outlook.com</a></p>';
const frontmatter = { "title": "联系方式", "published": "2025-08-23T00:00:00.000Z", "description": "我的联系方式有很多,我比较推荐的是通过我自己搭建的聊天软件进行联系(安全私密有保障) 新增加: tg频道:https://t.me/jinghao_blog 作者tg:https://t.me/haohaojing", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 2, "words": 355, "excerpt": "我的联系方式有很多,我比较推荐的是通过我自己搭建的聊天软件进行联系(安全私密有保障)" };
const file = "D:/github-git/fuwari-blog/src/content/spec/page-1770175976.592511.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
