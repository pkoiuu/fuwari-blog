import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>先说近的再说远的🎇</p>\n<p>2025.11.6</p>\n<p>网站logo全面换新~(￣▽￣)~* !</p>\n<p>!{“AIGC”:{“Label”:“1”,“ContentProducer”:“doubao”,“ProduceID”:“349e809cc59c4e82919371173a601b88”,“ReservedCode1”:"",“ContentPropagator”:"",“PropagateID”:"",“ReservedCode2”:""}}</p>\n<p>!{“AIGC”:{“Label”:“1”,“ContentProducer”:“doubao”,“ProduceID”:“29c4d76886b640dfb1414b28be61f681”,“ReservedCode1”:"",“ContentPropagator”:"",“PropagateID”:"",“ReservedCode2”:""}}</p>\n<p>2025.xx.xx</p>\n<p><strong>cdn优化,现在加载时间一般在三秒以内,如果运气好一秒以内就行了</strong></p>\n<p>**网站安全性大幅度增加 **</p>\n<p>现在的网络攻击好吓人,我这一个小站点也天天被恶意爆破…有时间我再专门写一篇文章</p>';
const frontmatter = { "title": "从上次更新至本次更新所有内容🎄", "published": "2025-10-16T00:00:00.000Z", "description": "先说近的再说远的🎇 2025.11.6 网站logo全面换新~￣▽￣~ {AIGC:{Label:1,ContentProducer:doubao,ProduceID:349e809cc59c4e82...", "tags": ["Uncategorized"], "category": "更新日志", "draft": false, "minutes": 1, "words": 93, "excerpt": "先说近的再说远的🎇" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.989226.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
