import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>一眨眼就到了小学<strong>最后</strong>一个六一儿童节,儿童节过了</p>\n<p>就要迎来人生中第一次大考(小升初<strong>漳州市</strong>统考)</p>\n<p>让我们最后狂欢一次,为小学画上一个完美的句号吧!</p>\n<p><strong>六一</strong>合照</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/05/1754062038-784ee19e4dbe2e84714b7f1e658fbb90.jpeg" alt="图片"></p>\n<p>六一礼物</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/05/1754062052-ac9416ca4da93befc743782de97a1ee5-scaled.jpeg" alt="图片"></p>\n<p><strong>班级毕业合照</strong></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/05/1754062032-61d3086cd93f305595412e045fdc60f9.jpeg" alt="图片"></p>\n<p><strong>祝贺:</strong></p>\n<p>天下小朋友都可以<strong>开开心心</strong>,<strong>快快乐乐</strong>,<strong>无忧无虑</strong>地生活着</p>\n<p>考上一个好学校,在考试中超常发挥</p>\n<p><strong>2025-5-31-13:10</strong></p>\n<p>六年一班<strong>黄浩景</strong></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/05/1754062052-ac9416ca4da93befc743782de97a1ee5-scaled.jpeg" alt="图片"></p>';
const frontmatter = { "title": "六一快乐!ヾ(≧▽≦*)o", "published": "2025-05-31T00:00:00.000Z", "description": "一眨眼就到了小学最后一个六一儿童节,儿童节过了 就要迎来人生中第一次大考(小升初漳州市统考) 让我们最后狂欢一次,为小学画上一个完美的句号吧! 六一合照 六一礼物 班级毕业合照\n", "tags": ["Uncategorized"], "category": "it", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/05/1754062052-ac9416ca4da93befc743782de97a1ee5-scaled.jpeg", "minutes": 1, "words": 135, "excerpt": "一眨眼就到了小学最后一个六一儿童节,儿童节过了" };
const file = "D:/github-git/fuwari-blog/src/content/posts/o.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
