import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>温馨提醒:</p>\n<p>所有福利都是在填写表格之后才生效的,如果没有填写请<a href="http://doc.hhj520.top/s/wwhEmq">立即填写</a></p>\n<p>福利</p>\n<p>1.享受免费的二级子域名</p>\n<p>2.享受私人聊天软件(服务器聊天软件也可以自己加群建群,邀请别人进来,作为管理员看不到你们的聊天记录非常安全)</p>\n<p>3.可以联系管理员获取免费的网页</p>\n<p>4.获取搭建服务器技术支持(包括小白从安装到游玩mc,帮助小白变成大神)</p>\n<p>5.免费的不限云盘</p>\n<p>6.免费的语音聊天软件</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/07/1754149618-1754061908-1c71fc065954d20b1de2af7f94257716.jpeg" alt="图片"></p>';
const frontmatter = { "title": "mc白鹤服务器福利", "published": "2025-08-04T00:00:00.000Z", "description": "温馨提醒: 所有福利都是在填写表格之后才生效的,如果没有填写请立即填写 福利 1.享受免费的二级子域名 2.享受私人聊天软件(服务器聊天软件也可以自己加群建群,邀请别人进来)\n", "tags": ["mc"], "category": "所有", "draft": false, "minutes": 1, "words": 161, "excerpt": "温馨提醒:" };
const file = "D:/github-git/fuwari-blog/src/content/posts/mc.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
