import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>真的好好看,杯子还是可以重复利用的嘞!关键是<strong>超级便宜</strong>一杯才十几块</p>";
const frontmatter = { "title": "也是买到瑞幸咖啡海绵宝宝周边了(*/ω＼*)", "published": "2025-05-02T00:00:00.000Z", "description": "真的好好看,杯子还是可以重复利用的嘞关键是超级便宜一杯才十几块", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 1, "words": 30, "excerpt": "真的好好看,杯子还是可以重复利用的嘞!关键是超级便宜一杯才十几块" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.909931.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
