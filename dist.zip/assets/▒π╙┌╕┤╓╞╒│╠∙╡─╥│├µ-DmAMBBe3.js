import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>便于复制粘贴的页面</p>";
const frontmatter = { "title": "便于复制粘贴的页面", "published": "1900-11-01T00:00:00.000Z", "description": "便于复制粘贴的页面", "tags": ["东山岛", "东山"], "category": "童年往事", "draft": false, "image": "https://kpkcdn.hhj520.top/uploads/20260208/4f8f15532a7bbd61be679b48c3320c55.webp", "minutes": 1, "words": 9, "excerpt": "便于复制粘贴的页面" };
const file = "D:/github-git/fuwari-blog/src/content/posts/便于复制粘贴的页面.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
