import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => `<p>正如标题所见,我的blog迎来了第一次换架构
这一次架构是<a href="https://astro.build/">Astro</a> &#x26; <a href="https://github.com/saicaca/fuwari">Fuwari</a>
引用教程&#x26;文献:
<a href="https://acofork.com/posts/fuwari/">https://acofork.com/posts/fuwari/</a>
本项目开源地址:</p>
<a id="GCl6tlh1-card" class="card-github fetch-waiting no-styling" href="https://github.com/pkoiuu/fuwari-blog" target="_blank" repo="pkoiuu/fuwari-blog"><div class="gc-titlebar"><div class="gc-titlebar-left"><div class="gc-owner"><div id="GCl6tlh1-avatar" class="gc-avatar"></div><div class="gc-user">pkoiuu</div></div><div class="gc-divider">/</div><div class="gc-repo">fuwari-blog</div></div><div class="github-logo"></div></div><div id="GCl6tlh1-description" class="gc-description">Waiting for api.github.com...</div><div class="gc-infobar"><div id="GCl6tlh1-stars" class="gc-stars">00K</div><div id="GCl6tlh1-forks" class="gc-forks">0K</div><div id="GCl6tlh1-license" class="gc-license">0K</div><span id="GCl6tlh1-language" class="gc-language">Waiting...</span></div><script id="GCl6tlh1-script" type="text/javascript" defer>
      fetch('https://api.github.com/repos/pkoiuu/fuwari-blog', { referrerPolicy: "no-referrer" }).then(response => response.json()).then(data => {
        document.getElementById('GCl6tlh1-description').innerText = data.description?.replace(/:[a-zA-Z0-9_]+:/g, '') || "Description not set";
        document.getElementById('GCl6tlh1-language').innerText = data.language;
        document.getElementById('GCl6tlh1-forks').innerText = Intl.NumberFormat('en-us', { notation: "compact", maximumFractionDigits: 1 }).format(data.forks).replaceAll(" ", '');
        document.getElementById('GCl6tlh1-stars').innerText = Intl.NumberFormat('en-us', { notation: "compact", maximumFractionDigits: 1 }).format(data.stargazers_count).replaceAll(" ", '');
        const avatarEl = document.getElementById('GCl6tlh1-avatar');
        avatarEl.style.backgroundImage = 'url(' + data.owner.avatar_url + ')';
        avatarEl.style.backgroundColor = 'transparent';
        document.getElementById('GCl6tlh1-license').innerText = data.license?.spdx_id || "no-license";
        document.getElementById('GCl6tlh1-card').classList.remove("fetch-waiting");
        console.log("[GITHUB-CARD] Loaded card for pkoiuu/fuwari-blog | GCl6tlh1.")
      }).catch(err => {
        const c = document.getElementById('GCl6tlh1-card');
        c?.classList.add("fetch-error");
        console.warn("[GITHUB-CARD] (Error) Loading card for pkoiuu/fuwari-blog | GCl6tlh1.")
      })
    <\/script></a>
<p>之前的博客(wp)有<strong>不可容忍</strong>缺点</p>
<section><h6 id="1速度慢前台很慢后台也很慢前台首次加载需要三四秒后台速度堪比拖拉机使用缓存也一样">1.速度慢(前台很慢后台也很慢,前台首次加载需要三四秒,后台速度堪比==拖拉机==…使用缓存也一样)<a class="anchor" href="#1速度慢前台很慢后台也很慢前台首次加载需要三四秒后台速度堪比拖拉机使用缓存也一样"><span class="anchor-icon" data-pagefind-ignore="">#</span></a></h6><p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770210585-processed-39.webp" alt="图片"></p></section>
<section><h6 id="2使用缓存的时候时不时就会后台无法登陆卡死我已经被困脑了一个月了直到今天才发现是那fuck的缓存换架构根本原因就是登陆不上去-">2.使用缓存的时候时不时就会后台无法登陆卡死(我已经被困脑了一个月了,直到今天才发现是那==fuck的缓存==…换架构根本原因就是登陆不上去 )<a class="anchor" href="#2使用缓存的时候时不时就会后台无法登陆卡死我已经被困脑了一个月了直到今天才发现是那fuck的缓存换架构根本原因就是登陆不上去-"><span class="anchor-icon" data-pagefind-ignore="">#</span></a></h6><p>搬移博客是一件非常麻烦的事情,前前后后弄了两天,还借助了AI工具
(so:辛苦ai了…)
<img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/11/1763298896-20251116131456658474.webp" alt="表情">
3.太容易遭受垃圾评论（我登录不上去的日子里，网站被垃圾评论攻击了，至少上百条）
<img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770212817-processed-41.webp" alt="mgxhz">
==<strong>感谢mgxhz的友情评论/提醒（本站评论的话也快了）</strong>==</p></section>
<section><h5 id="简单的介绍一下新博客吧">简单的介绍一下新博客吧<a class="anchor" href="#简单的介绍一下新博客吧"><span class="anchor-icon" data-pagefind-ignore="">#</span></a></h5><p>本博客灵感来源于<a href="2x.nz">2x的博客</a> 刚好他有写<a href="https://acofork.com/posts/fuwari/">部署教程</a> 于是frok了一下仓库, 把这一个仓库丢给AI，让它帮我优化一下，顺便让他把wp文章全部转化为.md</p><blockquote>
<p>(在做这一件事的时候，我的后台还登录不上去，登录不上去就没办法拿到wp的备份.xml，也就没有办法转换文章，我就是因为没办法登录后台才换架构的…我已经花了几个月的时间修了，还是没办法，就在我准备混吃等死的时候……脑子灵光一炸—是不是缓存在捣鬼，我把wp服务器的Redis 配置关掉了，果然…登录上去了，都进行到这一步了直接换架构吧…哎)</p>
</blockquote><p>转换的时候又花了好几个小时，那死AI不是把我图片转化没了，就是格式出问题，我还要写提示词，把图片全部换成CDN
<img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770212989-processed-42.webp" alt="..."><strong>哎，过程很艰辛，但是换来的性能提升也不止一点点(网站基础测试都为九十分加)</strong></p><p>还有就是我部署方式变了，由原来传统的服务器部署改为边缘节点（Server edge node）目前部署在eo( | hhj520.top | <a href="http://www.hhj520.top">www.hhj520.top</a> | )和esa( | esa.hhj520.top | )上,目前主力在eo，延迟少
<img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770213777-processed-45-scaled.webp" alt="gf">
由于部署方式变了，而且这一个没后台所以我只能用git 把项目托管在github 再在eo或esa上授权github 提交文章的时候只要我仓库一更新那么他们就也更新，也就实现了我提交仓库（文章）他们自动更新（==有兴趣的话，我出一篇技术类文章==）
<img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770213784-processed-44.webp" alt="gg">
我的文章也变了.md 使用标准的markdown编辑（使用2x推荐的黑曜石编辑器）
<img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770213680-processed-43.webp" alt="hai">
目前媒体还是存储在wp主要是来不及迁移，有时间迁移一下…</p><section><h6 id="再来介绍一下整体外观">再来介绍一下整体外观<a class="anchor" href="#再来介绍一下整体外观"><span class="anchor-icon" data-pagefind-ignore="">#</span></a></h6><p>整体外观我是用浅蓝色默认配置，有深暗两种配置，新增加时间线，联系方式和介绍合并在一起成为关于，生活所记和朋友圈照搬过来，一个超链接指向原来的旧站（原来的旧站没有关闭）下面有标签，还有我的个人介绍
<img src="https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770214256-processed-46.webp" alt="wg"><strong>另外站点名字改为haohao 的个人博客</strong>
差不多就是这样子了…
接下来我的计划</p><ul class="contains-task-list">
<li class="task-list-item"><input type="checkbox" checked disabled> 完成评论区</li>
<li class="task-list-item"><input type="checkbox" checked disabled> 深度优化</li>
<li class="task-list-item"><input type="checkbox" checked disabled> 保持更新</li>
</ul></section></section>`;
const frontmatter = { "title": "搬移博客-新架构-新部署方式", "published": "2026-02-04T00:00:00.000Z", "description": '"搬移博客-新架构-新部署方式"搬移博客-之前的blog登陆不上去,非常容易遭到垃圾评论的攻击,加上速度实在是不太理想...特地拥抱新的架构-Fuwari', "tags": ["Fuwari", "更新日志"], "category": "it", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2026/02/1770213777-processed-45-scaled.webp", "minutes": 5, "words": 901, "excerpt": "正如标题所见,我的blog迎来了第一次换架构\n这一次架构是Astro & Fuwari\n引用教程&文献:\nhttps://acofork.com/posts/fuwari/\n本项目开源地址:" };
const file = "D:/github-git/fuwari-blog/src/content/posts/搬移博客-新架构-新部署方式.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
