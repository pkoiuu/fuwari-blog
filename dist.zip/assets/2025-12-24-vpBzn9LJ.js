import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>平安夜快乐!!</p>\n<p>吃个苹果吧!hhh</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766587929-20251224145209869375.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766588059-20251224145419984458.webp" alt="图片"></p>';
const frontmatter = { "title": "2025-12-24 平安夜快乐! 吃个苹果吧", "published": "2025-12-24T00:00:00.000Z", "description": "平安夜快乐!! 吃个苹果吧!hhh\n", "tags": ["Uncategorized"], "category": "灵感", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766587929-20251224145209869375.webp", "minutes": 1, "words": 15, "excerpt": "平安夜快乐!!" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-12-24.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
