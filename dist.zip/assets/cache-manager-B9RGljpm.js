var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class CacheManager {
  constructor() {
    __publicField(this, "swRegistration", null);
    __publicField(this, "stats", {
      hitCount: 0,
      missCount: 0,
      totalRequests: 0,
      hitRate: "0%"
    });
  }
  /**
   * 检查 Service Worker 是否支持
   */
  isSupported() {
    return "serviceWorker" in navigator && "caches" in window;
  }
  /**
   * 注册 Service Worker（延迟注册，确保页面加载完成）
   */
  async register(delay = true) {
    if (!this.isSupported()) {
      console.warn("[CacheManager] Service Worker not supported");
      return;
    }
    const doRegister = async () => {
      try {
        this.swRegistration = await navigator.serviceWorker.register("/sw.js", {
          scope: "/",
          updateViaCache: "imports"
        });
        console.log(
          "[CacheManager] Service Worker registered:",
          this.swRegistration.scope
        );
        this.swRegistration.addEventListener("updatefound", () => {
          const newWorker = this.swRegistration?.installing;
          if (newWorker) {
            newWorker.addEventListener("statechange", () => {
              if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
                console.log("[CacheManager] New Service Worker available");
              }
            });
          }
        });
      } catch (error) {
        console.error("[CacheManager] Registration failed:", error);
      }
    };
    if (delay) {
      if ("requestIdleCallback" in window) {
        window.requestIdleCallback(
          () => {
            doRegister();
          },
          { timeout: 5e3 }
        );
      } else {
        if (document.readyState === "complete") {
          setTimeout(doRegister, 3e3);
        } else {
          window.addEventListener("load", () => {
            setTimeout(doRegister, 3e3);
          });
        }
      }
    } else {
      await doRegister();
    }
  }
  /**
   * 向 Service Worker 发送消息
   */
  async sendMessage(type, payload) {
    return new Promise((resolve, reject) => {
      const channel = new MessageChannel();
      channel.port1.onmessage = (event) => {
        if (event.data.error) {
          reject(event.data.error);
        } else {
          resolve(event.data);
        }
      };
      const controller = navigator.serviceWorker.controller;
      if (controller) {
        controller.postMessage({ type, payload }, [channel.port2]);
      } else {
        reject(new Error("Service Worker not active"));
      }
      setTimeout(() => {
        reject(new Error("Message timeout"));
      }, 5e3);
    });
  }
  /**
   * 获取缓存状态
   */
  async getStatus() {
    try {
      const response = await this.sendMessage("GET_STATUS");
      return response.payload;
    } catch (error) {
      console.error("[CacheManager] Failed to get status:", error);
      return null;
    }
  }
  /**
   * 获取缓存统计
   */
  getStats() {
    return { ...this.stats };
  }
  /**
   * 清理所有缓存
   */
  async clearCache() {
    try {
      const response = await this.sendMessage("CLEAR_CACHE");
      console.log("[CacheManager] Cache cleared:", response.payload);
      return response.payload;
    } catch (error) {
      console.error("[CacheManager] Failed to clear cache:", error);
      throw error;
    }
  }
  /**
   * 清理过期缓存
   */
  async cleanupExpired() {
    try {
      const response = await this.sendMessage("CLEANUP_EXPIRED");
      console.log("[CacheManager] Expired cache cleaned:", response.payload);
      return response.payload;
    } catch (error) {
      console.error("[CacheManager] Failed to cleanup:", error);
      throw error;
    }
  }
  /**
   * 刷新特定 URL 的缓存
   */
  async refreshCache(url) {
    try {
      const response = await this.sendMessage("REFRESH_CACHE", { url });
      console.log("[CacheManager] Cache refreshed:", response.payload);
      return response.payload;
    } catch (error) {
      console.error("[CacheManager] Failed to refresh:", error);
      throw error;
    }
  }
  /**
   * 更新 Service Worker
   */
  async update() {
    if (this.swRegistration) {
      await this.swRegistration.update();
      console.log("[CacheManager] Service Worker update checked");
    }
  }
  /**
   * 注销 Service Worker
   */
  async unregister() {
    if (this.swRegistration) {
      const result = await this.swRegistration.unregister();
      console.log("[CacheManager] Service Worker unregistered:", result);
      return result;
    }
    return false;
  }
  /**
   * 打印缓存报告到控制台
   */
  async printReport() {
    const status = await this.getStatus();
    if (!status) {
      console.log("%c[CacheManager] Cache not active", "color: #ff6b6b");
      return;
    }
    console.group(
      "%c📦 Cache Manager Report",
      "color: #4ecdc4; font-size: 14px; font-weight: bold;"
    );
    console.log(
      "%cStatus:",
      "color: #95e1d3; font-weight: bold;",
      status.status
    );
    console.log(
      "%cVersion:",
      "color: #95e1d3; font-weight: bold;",
      status.version
    );
    console.log(
      "%cCache Name:",
      "color: #95e1d3; font-weight: bold;",
      status.cacheName
    );
    console.log(
      "%cMax Age:",
      "color: #95e1d3; font-weight: bold;",
      `${status.maxAge / 1e3}s`
    );
    console.log(
      "%cEntries:",
      "color: #95e1d3; font-weight: bold;",
      status.entryCount
    );
    console.log(
      "%cTotal Size:",
      "color: #95e1d3; font-weight: bold;",
      `${status.totalSizeMB} MB`
    );
    if (status.entries.length > 0) {
      console.group(
        "%cCached Resources:",
        "color: #f38181; font-weight: bold;"
      );
      status.entries.forEach((entry, index) => {
        const age = entry.age ? `${(entry.age / 1e3 / 60).toFixed(1)}m` : "N/A";
        const size = entry.size ? `${(entry.size / 1024).toFixed(1)}KB` : "N/A";
        console.log(
          `  ${index + 1}. ${entry.url.substring(0, 60)}... (${size}, ${age})`
        );
      });
      console.groupEnd();
    }
    console.groupEnd();
  }
}
let cacheManager = null;
function initCacheManager() {
  if (typeof window === "undefined" || typeof document === "undefined") {
    return;
  }
  if (window.__CACHE_MONITOR__) {
    return;
  }
  cacheManager = new CacheManager();
  const cacheMonitor = {
    manager: cacheManager,
    // 快捷方法
    getStatus: () => cacheManager?.getStatus(),
    getStats: () => cacheManager?.getStats(),
    clearCache: () => cacheManager?.clearCache(),
    cleanupExpired: () => cacheManager?.cleanupExpired(),
    refreshCache: (url) => cacheManager?.refreshCache(url),
    update: () => cacheManager?.update(),
    unregister: () => cacheManager?.unregister(),
    report: () => cacheManager?.printReport(),
    // 帮助信息
    help: () => {
      console.log(
        "%c📦 Cache Monitor API",
        "color: #4ecdc4; font-size: 16px; font-weight: bold;"
      );
      console.log("");
      console.log("%cAvailable Methods:", "color: #95e1d3; font-weight: bold;");
      console.log("  __CACHE_MONITOR__.getStatus()     - Get cache status");
      console.log("  __CACHE_MONITOR__.getStats()      - Get cache statistics");
      console.log("  __CACHE_MONITOR__.clearCache()    - Clear all cache");
      console.log("  __CACHE_MONITOR__.cleanupExpired() - Clean expired cache");
      console.log(
        "  __CACHE_MONITOR__.refreshCache(url) - Refresh specific URL"
      );
      console.log(
        "  __CACHE_MONITOR__.update()        - Update Service Worker"
      );
      console.log(
        "  __CACHE_MONITOR__.unregister()    - Unregister Service Worker"
      );
      console.log("  __CACHE_MONITOR__.report()        - Print cache report");
      console.log("  __CACHE_MONITOR__.help()          - Show this help");
    }
  };
  Object.defineProperty(window, "__CACHE_MONITOR__", {
    value: cacheMonitor,
    writable: false,
    configurable: false,
    enumerable: true
  });
  cacheManager.register(true);
  setTimeout(() => {
    console.log(
      "%c📦 Cache Manager loaded. Type __CACHE_MONITOR__.help() for available commands.",
      "color: #4ecdc4;"
    );
  }, 3e3);
}
initCacheManager();
const cacheManager$1 = cacheManager;
export {
  cacheManager,
  cacheManager$1 as default,
  initCacheManager
};
