import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>时间过得好快,转眼间就来到了初一第二次月考</p>\n<p>在这之间发生许多事情:期中退步,学校创建小班化班级19班,加入19班…</p>\n<p>关于19班的事情在我的<a href="https://hhj520.top/%e6%97%a5%e5%b8%b8%f0%9f%95%b6%ef%b8%8f.html/">日记</a>中略有提到一嘴,有兴趣的可以去看一下</p>\n<p><strong>(19班和10班都是实验班, 19班小班化科创班的老师教, 19班主要是英语比较差数学比较好的, 19班数学平均分是除了科创班以外最好的)</strong></p>\n<p>具体细节可能要等到寒假再发出来了…</p>\n<p>总结一下这次考试吧~</p>\n<p>这次考试总体进步,折分年段排名<strong>250</strong> ,是不是挺喜剧hhh,另外提一嘴我们学校七年级差不多是900多人 ,接近一千</p>\n<p>总分667,满分850,</p>\n<p>语文111.5数学142英语108.5生物85地理81政治68历史71</p>\n<p><strong>其中数学年段排名40,班级排名第一</strong></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766842517-20251227133517592400.webp" alt="图片"></p>\n<p>总体我挺满意的,比上次期中进步了111名,比第一次月考退步两三名</p>\n<p>另外插一嘴我在19班是<strong>第一</strong>,在原班级<strong>第九名</strong>(进前十了!达到了我的目标不错不错)</p>\n<p>我们学校有一项”校长特别奖”每一次大考都有颁发,按照班级排名排序,每个班就只有一名学生(轮流,一个人拿了一次就不能再拿取另外一次)</p>\n<p>嘿嘿嘿,作为19班的第一理所应当有我(好开心好开心!ovo 第一次拿到校长特别奖,而且那一个奖牌还有真的黄金 )</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766842494-20251227133454970715.webp" alt="图片"></p>\n<p>2026.1.4才颁奖,到时候把照片发出来hhh</p>\n<p>(照片预留位)</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1767806658-20260107172418884212-scaled.webp" alt="图片"></p>\n<p>简单的总结一下各个学科</p>\n<p>数学:全是小失误,再努努力考145~150!</p>\n<p>语文:上120真的太难了,111.5年段排名233(我爸就是初中语文老师…没想到我竟然是理科比较好)</p>\n<p>英语:哎没事没事这次比上次进步了…主要拉开差距的一般是在英语</p>\n<p>小四门:除了政治,其他我都能接受…理科80++</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766842458-20251227133418995799.webp" alt="图片"></p>\n<p>其他证书jpge:(有压缩)</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1767106883-20251230150123348778-rotated.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1767106886-20251230150126473170-rotated.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1767106886-20251230150126193365-rotated.webp" alt="图片"></p>\n<p>其他证书pdf:</p>\n<p>电子版闽南师范大学附属龙溪学校七年级上册十九班第二次月考2025.12.22黄浩景—“成绩卓越奖-折分后年段排名250-总分667-班级排名第一”</p>\n<p>电子版闽南师范大学附属龙溪学校七年级上册十九班第二次月考2025.12.22黄浩景—“进步卓越奖-进步112名”</p>\n<p>电子版闽南师范大学附属龙溪学校七年级上册十九班第二次月考2025.12.22黄浩景—“数学单科卓越奖-班级第一名-年段四十名”</p>\n<p>电子版闽南师范大学附属龙溪学校七年级上册十九班第二次月考2025.12.22黄浩景—“校长特别奖[下载](/wp-content/uploads/2025/12/1767806711-20260107172511474570.pdf” class=“wp-block-file__button wp-element-button” download aria-describedby=“wp-block-file—media-3b75bfc4-1e39-4276-ac0f-359629ff9491)</p>';
const frontmatter = { "title": "初一第二次月考 | 班级第一 | 数学年段40", "published": "2025-12-27T00:00:00.000Z", "description": "时间过得好快,转眼间就来到了初一第二次月考 在这之间发生许多事情:期中退步,学校创建小班化班级19班,加入19班... 关于19班的事情在我的日记中略有提到一嘴,有兴趣的可以去看一下\n", "tags": ["Uncategorized"], "category": "青春", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766842458-20251227133418995799.webp", "minutes": 4, "words": 767, "excerpt": "时间过得好快,转眼间就来到了初一第二次月考" };
const file = "D:/github-git/fuwari-blog/src/content/posts/40.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
