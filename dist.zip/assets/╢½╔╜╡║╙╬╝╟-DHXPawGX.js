import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>东山岛隶属福建省漳州市东山县,是福建省第二大海岛,东山县第一大海岛\n但我作为一个”讲究”(漳州)人,居然在人生中前12年没去过…\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/cb46b011862c4d2b7ec51e7ae31ce310.gif" alt="hh">\n趁着这一个寒假,我决定去来一场说走就走的旅行(happy~)\n我家位于漳州市龙文区,距离东山岛<strong>149公里</strong>, 自驾游81%上高速的话需要一个小时52分钟,对我来说是有点久的,特别是在高速上…闷闷地而且还不能开窗户,对我来说就是一场折磨…\n<img src="https://kpkcdn.hhj520.top/uploads/20260210/b9cd360ebaf3a87da12de0b0a8c4d39a.webp" alt="06b7d7c382d18d34c7bb2d2a3c6647f6_2">\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/01408b18fdda672e5c307dfc7bb72359.gif" alt="hh">\n自驾游前期还是很爽  (坐上车的那一刻打开窗,感受到大自然的勃勃生机,听着车里的music,望着忙忙碌碌的人群,==<strong>幸福感爆棚!</strong>==)\n东山岛美景:\n<img src="https://kpkcdn.hhj520.top/uploads/20260210/05ec157229f63704aa730a4133b65e3d.webp" alt="微信图片_20260208113623_244_1">\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/a1d8ca7244c3e44f643342198848477e.jpg" alt="微信图片_20260208113631_246_1">\n<img src="https://kpkcdn.hhj520.top/uploads/20260210/d5f4b7a9ddc4c337ae4ecdcba78b6e7a.webp" alt="微信图片_20260208113641_249_1">\n<img src="https://kpkcdn.hhj520.top/uploads/20260210/47004264ec5509193d3cd2fac16d5cf7.webp" alt="微信图片_20260208113620_243_1">\n这一次去东山岛唯一一个遗憾就是没有去海滩,也没有住酒店(没有户口本)\n但是吃了海鲜,也是挺满足的,哈哈\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/549e1ee116e0e3090d3976035d41db67.webp" alt="微信图片_20260205164607_594_19">\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/9ad293aaf0ecbaf18fdae6b1b8f689c4.webp" alt="微信图片_20260205164608_595_19">\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/b320d4de40c1ae1900de51620c63d0ac.webp" alt="微信图片_20260205164606_593_19">\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/7678c91553f32e7bdae4dcbb5f684756.webp" alt="微信图片_20260205164612_599_19">\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/a67f1b72eb890aac6101423849feb0a1.webp" alt="微信图片_20260205164611_598_19">\n<img src="https://kpkcdn.hhj520.top/uploads/20260208/593a8f6c1514adc14d38d755f99fe1ac.webp" alt="微信图片_20260205164613_600_19">\n吃饱饭就回家啦~</p>';
const frontmatter = { "title": "东山岛游记", "published": "2026-02-05T00:00:00.000Z", "description": '身为一个"讲究"(漳州)人,十三年了第一次去东山岛...', "tags": ["东山岛", "东山"], "category": "童年往事", "draft": false, "image": "https://kpcdn2.hhj520.top/uploads/20260210/740d5fdbc1d02d2721d80fc0354e9c61.webp", "minutes": 2, "words": 314, "excerpt": "东山岛隶属福建省漳州市东山县,是福建省第二大海岛,东山县第一大海岛\n但我作为一个”讲究”(漳州)人,居然在人生中前12年没去过…\nhh\n趁着这一个寒假,我决定去来一场说走就走的旅行(happy~)\n我家位于漳州市龙文区,距离东山岛149公里, 自驾游81%上高速的话需要一个小时52分钟,对我来说是有点久的,特别是在高速上…闷闷地而且还不能开窗户,对我来说就是一场折磨…\n06b7d7c382d18d34c7bb2d2a3c6647f6_2\nhh\n自驾游前期还是很爽  (坐上车的那一刻打开窗,感受到大自然的勃勃生机,听着车里的music,望着忙忙碌碌的人群,==幸福感爆棚!==)\n东山岛美景:\n微信图片_20260208113623_244_1\n微信图片_20260208113631_246_1\n微信图片_20260208113641_249_1\n微信图片_20260208113620_243_1\n这一次去东山岛唯一一个遗憾就是没有去海滩,也没有住酒店(没有户口本)\n但是吃了海鲜,也是挺满足的,哈哈\n微信图片_20260205164607_594_19\n微信图片_20260205164608_595_19\n微信图片_20260205164606_593_19\n微信图片_20260205164612_599_19\n微信图片_20260205164611_598_19\n微信图片_20260205164613_600_19\n吃饱饭就回家啦~" };
const file = "D:/github-git/fuwari-blog/src/content/posts/东山岛游记.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
