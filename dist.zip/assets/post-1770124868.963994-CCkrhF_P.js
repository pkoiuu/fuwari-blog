import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>2025.8.25开始,我就开始了初中生活(初一)</p>\n<p>钱学森每次路过他的母校(北京师范大学附属中学)时总会说”这是他最熟悉的地方”</p>\n<p>可以见到初中是多么的忙碌,印象是多么的深刻,通过自己勤劳的努力去拼搏出一个好的未来(爱拼才会赢)</p>\n<p>上了初中之后,每天在家的时间变少,日子非常重复(基本全是三点一线线或者两点一线) 时间变少了,作业,科目变多了.时间在此时显得异常宝贵,只能压缩写文章的时间换取难得的宁静</p>\n<p>博客我也会每周进行更新,最近2025.8.25~2025.9.5我主要都是在更新@以及@</p>\n<p><strong>以后文章我会比较少更新,取而代之的是@ 还有其他的页面 (如果有什么有趣的事情/技术类/我会以文章的形式发出来,比较繁琐重复的我会以日记的形式发出(欢迎阅读🎇))</strong></p>\n<p>hhj</p>\n<p>2025.9.5</p>";
const frontmatter = { "title": "关于最近文章的更新🎉", "published": "2025-08-02T00:00:00.000Z", "description": "2025.8.25开始,我就开始了初中生活初一 钱学森每次路过他的母校北京师范大学附属中学时总会说这是他最熟悉的地方 可以见到初中是多么的忙碌,印象是多么的深刻,通过自己勤劳的努力去拼搏出一个好的未来...", "tags": ["Uncategorized"], "category": "灵感", "draft": false, "minutes": 1, "words": 264, "excerpt": "2025.8.25开始,我就开始了初中生活(初一)" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.963994.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
