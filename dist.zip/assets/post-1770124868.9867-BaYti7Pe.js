import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>本人因为前一段时间学业繁重,不堪重负,停止更新一段时间</p>\n<p>现在期中考结束,有一会儿放松的时间,决定恢复更新</p>";
const frontmatter = { "title": "博客恢复更新通知🎯", "published": "2024-01-01T00:00:00.000Z", "description": "本人因为前一段时间学业繁重,不堪重负,停止更新一段时间 现在期中考结束,有一会儿放松的时间,决定恢复更新", "tags": ["Uncategorized"], "category": "青春", "draft": false, "minutes": 1, "words": 47, "excerpt": "本人因为前一段时间学业繁重,不堪重负,停止更新一段时间" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.9867.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
