import "./_page_.1dab3c66-CzKjPEEM.js";
import { c as createComponent, b as createAstro, a as renderComponent, r as renderTemplate, u as unescapeHTML, m as maybeRenderHead, d as addAttribute } from "./astro/server-C-80V8Is.js";
import { s as siteConfig, h as getCollection, p as profileConfig, i as i18n, I as I18nKey, c as getDir } from "./content-utils-BhOblCvP.js";
import path from "node:path";
import $$License from "./License-HKo38d7W.js";
import $$Markdown from "./Markdown-D6Jr8Yob.js";
import { $ as $$MainGridLayout, a as $$Icon, b as $$ImageWrapper } from "./MainGridLayout-CmSTpEtG.js";
import $$Comment from "./Comment-3_GEVStI.js";
import $$PostMeta from "./PostMeta-BOQzl5jF.js";
import { formatDateToYYYYMMDD } from "./date-utils-Ch-MCoAg.js";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro();
async function getStaticPaths() {
  const specEntries = await getCollection("spec");
  return specEntries.map((entry) => {
    const idParts = entry.id.split("/");
    const fileName = idParts[idParts.length - 1];
    const slug = fileName.replace(".md", "");
    return { params: { slug }, props: { entry } };
  });
}
const $$ = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  const { entry } = Astro2.props;
  const { Content, headings } = await entry.render();
  const { remarkPluginFrontmatter } = await entry.render();
  const jsonLd = { "@context": "https://schema.org", "@type": "BlogPosting", headline: entry.data.title || "Spec Page", description: entry.data.description || entry.data.title || "Spec Page", author: { "@type": "Person", name: profileConfig.name, url: Astro2.site }, datePublished: entry.data.published ? formatDateToYYYYMMDD(entry.data.published) : (/* @__PURE__ */ new Date()).toISOString().split("T")[0], inLanguage: entry.data.lang ? entry.data.lang.replace("_", "-") : siteConfig.lang.replace("_", "-") };
  return renderTemplate`${renderComponent($$result, "MainGridLayout", $$MainGridLayout, { "banner": entry.data.image, "title": entry.data.title || "Spec Page", "description": entry.data.description || entry.data.title || "Spec Page", "lang": entry.data.lang, "setOGTypeArticle": true, "headings": headings }, { "default": async ($$result2) => renderTemplate`  ${maybeRenderHead()}<div class="flex w-full rounded-[var(--radius-large)] overflow-hidden relative mb-4"> <div id="post-container"${addAttribute(["card-base z-10 px-6 md:px-9 pt-6 pb-4 relative w-full ", {}], "class:list")}> <!-- word count and reading time --> <div class="flex flex-row text-black/30 dark:text-white/30 gap-5 mb-3 transition onload-animation"> <div class="flex flex-row items-center"> <div class="transition h-6 w-6 rounded-md bg-black/5 dark:bg-white/10 text-black/50 dark:text-white/50 flex items-center justify-center mr-2"> ${renderComponent($$result2, "Icon", $$Icon, { "name": "material-symbols:notes-rounded" })} </div> <div class="text-sm">${remarkPluginFrontmatter.words} ${" " + i18n(I18nKey.wordsCount)}</div> </div> <div class="flex flex-row items-center"> <div class="transition h-6 w-6 rounded-md bg-black/5 dark:bg-white/10 text-black/50 dark:text-white/50 flex items-center justify-center mr-2"> ${renderComponent($$result2, "Icon", $$Icon, { "name": "material-symbols:schedule-outline-rounded" })} </div> <div class="text-sm"> ${remarkPluginFrontmatter.minutes} ${" " + i18n(remarkPluginFrontmatter.minutes === 1 ? I18nKey.minuteCount : I18nKey.minutesCount)} </div> </div> </div> <!-- title --> <div class="relative onload-animation"> <div data-pagefind-body data-pagefind-weight="10" data-pagefind-meta="title" class="transition w-full block font-bold mb-3
                    text-3xl md:text-[2.25rem]/[2.75rem]
                    text-black/90 dark:text-white/90
                    md:before:w-1 before:h-5 before:rounded-md before:bg-[var(--primary)]
                    before:absolute before:top-[0.75rem] before:left-[-1.125rem]
                "> ${entry.data.title || "Spec Page"} </div> </div> <!-- metadata --> <div class="onload-animation"> ${renderComponent($$result2, "PostMetadata", $$PostMeta, { "class": "mb-5", "published": entry.data.published || /* @__PURE__ */ new Date(), "updated": entry.data.updated, "tags": entry.data.tags || [], "category": entry.data.category || "" })} ${!entry.data.image && renderTemplate`<div class="border-[var(--line-divider)] border-dashed border-b-[1px] mb-5"></div>`} </div> <!-- always show cover as long as it has one --> ${entry.data.image && renderTemplate`${renderComponent($$result2, "ImageWrapper", $$ImageWrapper, { "id": "post-cover", "src": entry.data.image, "basePath": path.join("content/spec/", getDir(entry.id)), "class": "mb-8 rounded-xl banner-container onload-animation" })}`} ${renderComponent($$result2, "Markdown", $$Markdown, { "class": "mb-6 markdown-content onload-animation" }, { "default": async ($$result3) => renderTemplate` ${renderComponent($$result3, "Content", Content, {})} ` })} ${renderTemplate`${renderComponent($$result2, "License", $$License, { "title": entry.data.title || "Spec Page", "slug": entry.slug, "pubDate": entry.data.published, "class": "mb-6 rounded-xl license-container onload-animation" })}`} <!-- 评论系统 --> ${renderComponent($$result2, "Comment", $$Comment, {})} </div> </div> `, "head": async ($$result2) => renderTemplate(_a || (_a = __template(['<script type="application/ld+json">', "<\/script>"])), unescapeHTML(JSON.stringify(jsonLd))) })}`;
}, "D:/github-git/fuwari-blog/src/pages/spec/[...slug].astro", void 0);
const $$file = "D:/github-git/fuwari-blog/src/pages/spec/[...slug].astro";
const $$url = "/spec/[...slug]/";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
export {
  _page as _
};
