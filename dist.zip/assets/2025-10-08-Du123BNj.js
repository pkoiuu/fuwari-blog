import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>自言自语: 国庆这几天都没有怎么更新文章,今天把补文章上去</p>\n<p><strong>1.更换CDN</strong></p>\n<p>原本使用的CDN(𝙌𝙞𝙪𝙙𝙪𝙣) 已经关闭,现在改用腾讯的edgeone免费版</p>\n<p>并且优选了一下ip,使用的是”<strong>NB 优选服务</strong>”有兴趣的可以访问一下<a href="https://www.byoip.top/">https://www.byoip.top/</a></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759929486-20251008131806083152.webp" alt="图片"></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759929489-20251008131809816298.webp" alt="图片"></p>\n<p>没了…cdn耗费了很大精力</p>\n<p>ai</p>';
const frontmatter = { "title": "博客更新日志 2025.10.8", "published": "2025-10-08T00:00:00.000Z", "description": "自言自语: 国庆这几天都没有怎么更新文章,今天把补文章上去 1.更换CDN 原本使用的CDN(𝙌𝙞𝙪𝙙𝙪𝙣) 已经关闭,现在改用腾讯的edgeone免费版 并且优选了一下ip\n", "tags": ["更新日志"], "category": "更新日志", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1759929486-20251008131806083152.webp", "minutes": 1, "words": 95, "excerpt": "自言自语: 国庆这几天都没有怎么更新文章,今天把补文章上去" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-10-08.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
