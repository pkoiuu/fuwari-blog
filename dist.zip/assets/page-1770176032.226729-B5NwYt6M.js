import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>2025.12.21-21:05</p>\n<p>冬至美食,深夜放毒~</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/12/1766322150-20251221130230854748.webp" alt=""></p>\n<p>2025.10.22-6:27</p>\n<p>真的是一秒入冬!</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1761085786-20251021222946644900.webp" alt=""></p>\n<p>2025.10.20-20.22</p>\n<p>为乡村教育献出自己的一份力量🫠</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1760963208-20251020122648247029.webp" alt=""></p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1760963232-20251020122712364455.webp" alt=""></p>\n<p>2025.10.19-4:11</p>\n<p>朋友圈的第一条,纪念一下hhh,主要用来发布日常,图文结合</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/10/1760818411-20251018201331715013.webp" alt=""></p>';
const frontmatter = { "title": "朋友圈🎉", "published": "2025-10-18T00:00:00.000Z", "description": "2025.12.21-21:05 冬至美食,深夜放毒~ 2025.10.22-6:27 真的是一秒入冬! 2025.10.20-20.22 为乡村", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 1, "words": 57, "excerpt": "2025.12.21-21:05" };
const file = "D:/github-git/fuwari-blog/src/content/spec/page-1770176032.226729.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
