const contentAssets = /* @__PURE__ */ new Map();
export {
  contentAssets as default
};
