import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>第1次摆摊失败了第1次摆摊失败了 第1次摆摊失败了</p>\n<p>公园不让摆摊 :(</p>\n<p>摆好城管就来了,好在拍了一张照,有了第一个客人awa</p>";
const frontmatter = { "title": "汤圆小猫咪摆摊记（结束）", "published": "2025-04-18T00:00:00.000Z", "description": "第1次摆摊失败了第1次摆摊失败了 第1次摆摊失败了 公园不让摆摊 : 摆好城管就来了,好在拍了一张照,有了第一个客人awa", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 1, "words": 52, "excerpt": "第1次摆摊失败了第1次摆摊失败了 第1次摆摊失败了" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.886852.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
