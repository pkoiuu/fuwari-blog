import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>2025.8.25开始,我就开始了初中生活(初一)</p>\n<p>钱学森每次路过他的母校(北京师范大学附属中学)时总会说”这是他最熟悉的地方”</p>\n<p>可以见到初中是多么的忙碌,印象是多么的深刻,通过自己勤劳的努力去拼搏出一个好的未来(爱拼才会赢)</p>\n<p>上了初中之后,每天在家的时间变少,日子非常重复(基本全是三点一线线或者两点一线)   时间变少了,作业,科目变多了.时间在此时显得异常宝贵,只能压缩写文章的时间换取难得的宁静</p>\n<p>博客我也会每周进行更新,最近2025.8.25~2025.9.5我主要都是在更新@[生活琐记](<a href="https://hhj520.top/%e6%97%a5%e5%b8%b8%f0%9f%95%b6%ef%b8%8f/">https://hhj520.top/%e6%97%a5%e5%b8%b8%f0%9f%95%b6%ef%b8%8f/</a>” data-type=“page” data-id=“468)以及@[日省小笺🎯](<a href="https://hhj520.top/%e6%97%a5%e7%9c%81%e5%b0%8f%e7%ac%ba%f0%9f%8e%af/">https://hhj520.top/%e6%97%a5%e7%9c%81%e5%b0%8f%e7%ac%ba%f0%9f%8e%af/</a>” data-type=“page” data-id=“463)</p>\n<p><strong>以后文章我会比较少更新,取而代之的是@[生活琐记](<a href="https://hhj520.top/%e6%97%a5%e5%b8%b8%f0%9f%95%b6%ef%b8%8f/">https://hhj520.top/%e6%97%a5%e5%b8%b8%f0%9f%95%b6%ef%b8%8f/</a>” data-type=“page” data-id=“468) 还有其他的页面 (如果有什么有趣的事情/技术类/我会以文章的形式发出来,比较繁琐重复的我会以日记的形式发出(欢迎阅读🎇))</strong></p>\n<p><img src="/wp-content/uploads/2025/09/1757075609-20250905123329623744.webp" alt=""></p>\n<p>hhj</p>\n<p>2025.9.5</p>';
const frontmatter = { "title": "关于最近文章的更新🎉", "published": "2025-09-05T00:00:00.000Z", "description": '2025.8.25开始,我就开始了初中生活(初一)\n\n钱学森每次路过他的母校(北京师范大学附属中学)时总会说"这是他最熟悉的地方"\n\n可以见到初中是多么的忙碌,印象是多么的深刻,通过自己勤劳的\n', "tags": ["文章", "生活"], "category": "灵感", "draft": false, "minutes": 1, "words": 285, "excerpt": "2025.8.25开始,我就开始了初中生活(初一)" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770176032.339126.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
