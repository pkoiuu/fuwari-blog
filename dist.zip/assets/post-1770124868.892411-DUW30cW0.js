import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p><strong>PICUI</strong>图床(限制100mb,目前在用)</p>\n<p>图床小镇(目前在用)PICUI图床<a href="https://picui.cn/user/dashboard(%E9%99%90%E5%88%B6100mb,%E7%9B%AE%E5%89%8D%E5%9C%A8%E7%94%A8)**PICUI**%E5%9B%BE%E5%BA%8A(%E9%99%90%E5%88%B6100mb,%E7%9B%AE%E5%89%8D%E5%9C%A8%E7%94%A8)**PICUI**%E5%9B%BE%E5%BA%8A(%E9%99%90%E5%88%B6100mb,%E7%9B%AE%E5%89%8D%E5%9C%A8%E7%94%A8)**PICUI**%E5%9B%BE%E5%BA%8A(%E9%99%90%E5%88%B6100mb,%E7%9B%AE%E5%89%8D%E5%9C%A8%E7%94%A8)">https://picui.cn/user/dashboard(限制100mb,目前在用)**PICUI**图床(限制100mb,目前在用)**PICUI**图床(限制100mb,目前在用)**PICUI**图床(限制100mb,目前在用)</a></p>\n<p>聚合图床 (1000张,无加速)</p>';
const frontmatter = { "title": "常用的图床🫠", "published": "2025-04-15T00:00:00.000Z", "description": "PICUI图床限制100mb,目前在用 图床小镇目前在用PICUI图床 聚合图床&nbsp;1000张,无加速", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 1, "words": 68, "excerpt": "PICUI图床(限制100mb,目前在用)" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.892411.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
