import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>邻居吵架,大打出手(真实经历)</p>\n<p>2025-12-18星期四<strong>深夜</strong>11点多</p>\n<p>同一层住<strong>最右边</strong>的邻居夫妻吵架,吵了十几分钟</p>\n<p>我们是住在<strong>偏左</strong>的,他们的声音之大又尖锐无比,吵得很脏,吵得让人无法睡觉,我爸在里面骂了他们,其中一<strong>花臂光着身子,目测150斤又凶又彪悍</strong>的男子耍酒疯与我爸争执,从而演变成互相对骂</p>\n<p>耍酒疯男子骂不过,便随即同吵架的妻子一起踹门,同行另外一名男子见状连忙上前拉架,耍酒疯男子疑似喝假酒了,脾气极为暴躁,一个壮汉都拉都拉不动,使劲踹我家的门,我爸见状生了气,大吼一声,手一指,大声对骂</p>\n<p>耍酒疯的男子以及他的妻子一个在那边使劲踹门,一个用砖头砸门,我爸也见门要顶不住,箭步上前顶住大门,初一的我见此尤为愤怒,扫把一拿,随即加入对骂,奈何人家彪悍体壮,我们这些”文弱书生 “怎么抵抗得住</p>\n<p><strong>高潮来了!</strong></p>\n<p>门踹开了,我爸那九十多斤的身体一振,被铁门直直撞上鼻梁(还好我爸高鼻梁,要不然这一下可就脑震荡了)</p>\n<p>鼻子哗哗流血,手机噗嗤一下掉地上摔出了痕迹,我仍然上前去查看我爸的受伤程度</p>\n<p>我们报了警</p>\n<p>一会儿上来了两三个武警,他们那一群低素质没什么学历收入又低的人依就还在那边叫嚣</p>\n<p>我爸鼻子出现了一个伤口,哗哗流血,门已经被踹出了痕迹,上还是可见砖头还有血,<strong>我吓得腿都软</strong></p>\n<p>不过我爸挺冷静,第一时间叫了人换锁,保护我,以及贵重财产的安全(虽然最终也是出去住了)</p>\n<p><strong>由于太晚了而且我爸也在客厅小酌了一杯,不能录口供,先去看了一下医生</strong></p>\n<p>最终情况是这样的:</p>\n<p>1.鼻子骨折了而且有一个伤口需要缝合</p>\n<p>2.门被踹坏了</p>\n<p>3.一台iPhone的屏幕坏了</p>\n<p>随后我们去酒店入住了(我爸他那一个死酒鬼,还想要喝酒)</p>\n<p><strong>由于当时的明天是星期五2025.12.19,我需要去上学,所以参加不了他们的争论</strong></p>\n<p>星期五晚上回家时处决结果已经出来了</p>\n<p><strong>花臂光着身子,目测150斤又凶又彪悍</strong>,张嘴闭嘴就是粗话,低素质又没学识的男子以及同行的所有人,被罚款一万六(16000)</p>\n<p>我爸对此很不接受,没有好气的出去警察局了(虽然在赔偿金额上我们获得了比较好的数目,但是还是达不到刑事处罚)</p>\n<p>这件事也就这么翻篇了,我挺难接受的,我爸也挺难接受,只能说有没有素质没有文化,就是对社会没有用处的东西,辜负了国家,辜负了自己,辜负了家庭!</p>\n<p>同时也提醒大家</p>\n<p>切勿和小人同行,切勿和低素质的人同行,切勿和没有文化的人同行,为自己做出的行为负责,做事情之前要考虑清楚,不然后悔莫及 !</p>";
const frontmatter = { "title": "震惊!某小区惊现扰民，双方大打出手!", "published": "2025-12-20T00:00:00.000Z", "description": "邻居吵架,大打出手真实经历 2025-12-18星期四深夜11点多 同一层住最右边的邻居夫妻吵架,吵了十几分钟 我们是住在偏左的,他们的声音之大又尖锐无比,吵得很脏,吵得让人无法睡觉,我爸在里面骂了他...", "tags": ["Uncategorized"], "category": "世界上的小人", "draft": false, "minutes": 4, "words": 863, "excerpt": "邻居吵架,大打出手(真实经历)" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.998623.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
