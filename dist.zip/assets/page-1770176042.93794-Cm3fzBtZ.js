import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p><a href="https://mgxhz.dpdns.org/">MGXHZ博客</a></p>\n<p>[天海博客](<a href="https://woolyun.com/">https://woolyun.com/</a>” target=“_blank” rel=“noreferrer noopener)</p>\n<p>建站经验记录，实用工具推荐，免费资源分享</p>\n<p><a href="https://codfish.top">Codfish Blog</a></p>\n<p>🐟🐟🐟</p>';
const frontmatter = { "title": "友情链接🎨", "published": "2025-10-18T00:00:00.000Z", "description": "MGXHZ博客 天海博客 建站经验记录，实用工具推荐，免费资源分享 Codfish Blog 🐟🐟🐟", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 1, "words": 31, "excerpt": "MGXHZ博客" };
const file = "D:/github-git/fuwari-blog/src/content/spec/page-1770176042.93794.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
