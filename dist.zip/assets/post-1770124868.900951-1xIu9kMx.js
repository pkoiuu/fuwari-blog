import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>六年时光飞逝,转眼已经到了拍毕业照的时候</p>\n<p>我还来不及感慨小学的乐趣,时间把我我推上了初中的赛道上奔跑</p>\n<p>虽心有遗憾,但是留下遗憾,保存一点点念想,岂不更好?</p>\n<p><strong>或许</strong></p>\n<p>未来的我看到这一篇文章时,心中泛起一点酸涩,回想起自己青春时曾经留下的遗憾,望着那一张毕业照,感慨着时间飞快,感慨自己的无知… <strong>人生的道路还很长,仍需要努力向前走,加油!</strong></p>\n<p>2025-5-31-13:56</p>\n<p>六年一班<strong>黄浩景</strong></p>";
const frontmatter = { "title": "小学毕业照😶‍🌫️", "published": "2025-05-31T00:00:00.000Z", "description": "六年时光飞逝,转眼已经到了拍毕业照的时候 我还来不及感慨小学的乐趣,时间把我我推上了初中的赛道上奔跑 虽心有遗憾,但是留下遗憾,保存一点点念想,岂不更好? 或许 未来的我看到这一篇文章时,心中泛起一点...", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 1, "words": 155, "excerpt": "六年时光飞逝,转眼已经到了拍毕业照的时候" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.900951.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
