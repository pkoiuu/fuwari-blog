import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>1.广告与友情链接</p>\n<p>本站为个人网站,<strong>不接受广告</strong>!!!</p>\n<p>如果需要友链,请通过另外一个页面的联系方式进行联系</p>\n<p>2.评论的规范</p>\n<p>我们网站评论需要遵守 **“中华人民共和国宪法”**保障其的合法性</p>\n<p>另外<strong>不能</strong>出现包括但不限以下评论(举例说明,一切解释权归站长所有)</p>\n<ol>\n<li>\n<p>危害国家安全</p>\n</li>\n<li>\n<p>进行语言辱骂</p>\n</li>\n<li>\n<p>语言包含暴力倾向</p>\n</li>\n<li>\n<p>透露别人的身份信息</p>\n</li>\n<li>\n<p>在评论区打广告  (特别不允许)</p>\n</li>\n</ol>\n<p><strong>6. 黄色,赌博,毒品相关内容</strong> (一经发现绝对举报)</p>\n<p><strong>我们提倡的评论内容</strong></p>\n<p>1.友善且友好,回复的口气要好</p>\n<p>2.不使用过激性语言,做一个文明人</p>\n<p>3.正常的问问题**(你说的语言具有讽刺那就不叫提问题那叫找事情)**</p>\n<p>如果发布违规内容/被我认为垃圾内容比如</p>\n<p>(危害国家安全,语言辱骂,暴力倾向,别人的身份信息)</p>\n<p><strong>那么网站有权删除你的评论</strong></p>\n<p>(访客在本博客评论即说明已经同意以上评论规则，若您不同意以上规则请不要留下评论)</p>\n<p>规则补充</p>\n<p>1.规则不定时的修改,一切都以新规则为判断要点</p>\n<p>2.我们欢迎朋友前来,但是<strong>绝对不欢迎挑事者</strong></p>";
const frontmatter = { "title": "本站规则(新人必看)", "published": "2024-01-01T00:00:00.000Z", "description": "1.广告与友情链接 本站为个人网站,不接受广告 如果需要友链,请通过另外一个页面的联系方式进行联系 2.评论的规范 我们网站评论需要遵守 中华人民共和国宪法保障其的合法性 另外不能出现包括但不限以下评...", "tags": ["Uncategorized"], "category": "所有", "draft": false, "minutes": 2, "words": 364, "excerpt": "1.广告与友情链接" };
const file = "D:/github-git/fuwari-blog/src/content/posts/post-1770124868.95393.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
