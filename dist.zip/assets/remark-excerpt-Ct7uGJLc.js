var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _out, _on_destroy, _is_component_body, _parent, _Renderer_instances, collect_on_destroy_fn, traverse_components_fn, collect_ondestroy_fn, _Renderer_static, render_fn, render_async_fn, collect_content_fn, collect_content_async_fn, open_render_fn, close_render_fn, _title;
import { V as clsx$1 } from "./astro/server-C-80V8Is.js";
function await_invalid() {
  const error = new Error(`await_invalid
Encountered asynchronous work while rendering synchronously.
https://svelte.dev/e/await_invalid`);
  error.name = "Svelte error";
  throw error;
}
var ssr_context = null;
function set_ssr_context(v) {
  ssr_context = v;
}
function push(fn) {
  ssr_context = { p: ssr_context, c: null, r: null };
}
function pop() {
  ssr_context = /** @type {SSRContext} */
  ssr_context.p;
}
const STALE_REACTION = new class StaleReactionError extends Error {
  constructor() {
    super(...arguments);
    __publicField(this, "name", "StaleReactionError");
    __publicField(this, "message", "The reaction that called `getAbortSignal()` was re-run or destroyed");
  }
}();
let controller = null;
function abort() {
  controller?.abort(STALE_REACTION);
  controller = null;
}
function createRawSnippet(fn) {
  return (renderer2, ...args) => {
    var getters = (
      /** @type {Getters<Params>} */
      args.map((value) => () => value)
    );
    renderer2.push(
      fn(...getters).render().trim()
    );
  };
}
const HYDRATION_START = "[";
const HYDRATION_END = "]";
const ELEMENT_IS_NAMESPACED = 1;
const ELEMENT_PRESERVE_ATTRIBUTE_CASE = 1 << 1;
const ELEMENT_IS_INPUT = 1 << 2;
const ATTR_REGEX = /[&"<]/g;
const CONTENT_REGEX = /[&<]/g;
function escape_html(value, is_attr) {
  const str = String(value ?? "");
  const pattern = is_attr ? ATTR_REGEX : CONTENT_REGEX;
  pattern.lastIndex = 0;
  let escaped = "";
  let last = 0;
  while (pattern.test(str)) {
    const i = pattern.lastIndex - 1;
    const ch = str[i];
    escaped += str.substring(last, i) + (ch === "&" ? "&amp;" : ch === '"' ? "&quot;" : "&lt;");
    last = i + 1;
  }
  return escaped + str.substring(last);
}
const replacements = {
  translate: /* @__PURE__ */ new Map([
    [true, "yes"],
    [false, "no"]
  ])
};
function attr(name, value, is_boolean = false) {
  if (name === "hidden" && value !== "until-found") {
    is_boolean = true;
  }
  if (value == null || !value && is_boolean) return "";
  const normalized = name in replacements && replacements[name].get(value) || value;
  const assignment = is_boolean ? "" : `="${escape_html(normalized, true)}"`;
  return ` ${name}${assignment}`;
}
function clsx(value) {
  if (typeof value === "object") {
    return clsx$1(value);
  } else {
    return value ?? "";
  }
}
const whitespace = [..." 	\n\r\f \v\uFEFF"];
function to_class(value, hash, directives) {
  var classname = value == null ? "" : "" + value;
  if (hash) {
    classname = classname ? classname + " " + hash : hash;
  }
  if (directives) {
    for (var key in directives) {
      if (directives[key]) {
        classname = classname ? classname + " " + key : key;
      } else if (classname.length) {
        var len = key.length;
        var a = 0;
        while ((a = classname.indexOf(key, a)) >= 0) {
          var b = a + len;
          if ((a === 0 || whitespace.includes(classname[a - 1])) && (b === classname.length || whitespace.includes(classname[b]))) {
            classname = (a === 0 ? "" : classname.substring(0, a)) + classname.substring(b + 1);
          } else {
            a = b;
          }
        }
      }
    }
  }
  return classname === "" ? null : classname;
}
function append_styles(styles, important = false) {
  var separator = important ? " !important;" : ";";
  var css = "";
  for (var key in styles) {
    var value = styles[key];
    if (value != null && value !== "") {
      css += " " + key + ": " + value + separator;
    }
  }
  return css;
}
function to_css_name(name) {
  if (name[0] !== "-" || name[1] !== "-") {
    return name.toLowerCase();
  }
  return name;
}
function to_style(value, styles) {
  if (styles) {
    var new_style = "";
    var normal_styles;
    var important_styles;
    if (Array.isArray(styles)) {
      normal_styles = styles[0];
      important_styles = styles[1];
    } else {
      normal_styles = styles;
    }
    if (value) {
      value = String(value).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
      var in_str = false;
      var in_apo = 0;
      var in_comment = false;
      var reserved_names = [];
      if (normal_styles) {
        reserved_names.push(...Object.keys(normal_styles).map(to_css_name));
      }
      if (important_styles) {
        reserved_names.push(...Object.keys(important_styles).map(to_css_name));
      }
      var start_index = 0;
      var name_index = -1;
      const len = value.length;
      for (var i = 0; i < len; i++) {
        var c = value[i];
        if (in_comment) {
          if (c === "/" && value[i - 1] === "*") {
            in_comment = false;
          }
        } else if (in_str) {
          if (in_str === c) {
            in_str = false;
          }
        } else if (c === "/" && value[i + 1] === "*") {
          in_comment = true;
        } else if (c === '"' || c === "'") {
          in_str = c;
        } else if (c === "(") {
          in_apo++;
        } else if (c === ")") {
          in_apo--;
        }
        if (!in_comment && in_str === false && in_apo === 0) {
          if (c === ":" && name_index === -1) {
            name_index = i;
          } else if (c === ";" || i === len - 1) {
            if (name_index !== -1) {
              var name = to_css_name(value.substring(start_index, name_index).trim());
              if (!reserved_names.includes(name)) {
                if (c !== ";") {
                  i++;
                }
                var property = value.substring(start_index, i).trim();
                new_style += " " + property + ";";
              }
            }
            start_index = i + 1;
            name_index = -1;
          }
        }
      }
    }
    if (normal_styles) {
      new_style += append_styles(normal_styles);
    }
    if (important_styles) {
      new_style += append_styles(important_styles, true);
    }
    new_style = new_style.trim();
    return new_style === "" ? null : new_style;
  }
  return value == null ? null : String(value);
}
const DOM_BOOLEAN_ATTRIBUTES = [
  "allowfullscreen",
  "async",
  "autofocus",
  "autoplay",
  "checked",
  "controls",
  "default",
  "disabled",
  "formnovalidate",
  "indeterminate",
  "inert",
  "ismap",
  "loop",
  "multiple",
  "muted",
  "nomodule",
  "novalidate",
  "open",
  "playsinline",
  "readonly",
  "required",
  "reversed",
  "seamless",
  "selected",
  "webkitdirectory",
  "defer",
  "disablepictureinpicture",
  "disableremoteplayback"
];
function is_boolean_attribute(name) {
  return DOM_BOOLEAN_ATTRIBUTES.includes(name);
}
const BLOCK_OPEN = `<!--${HYDRATION_START}-->`;
const BLOCK_CLOSE = `<!--${HYDRATION_END}-->`;
function experimental_async_ssr() {
  {
    console.warn(`https://svelte.dev/e/experimental_async_ssr`);
  }
}
const _Renderer = class _Renderer {
  /**
   * @param {SSRState} global
   * @param {Renderer | undefined} [parent]
   */
  constructor(global, parent) {
    __privateAdd(this, _Renderer_instances);
    /**
     * The contents of the renderer.
     * @type {RendererItem[]}
     */
    __privateAdd(this, _out, []);
    /**
     * Any `onDestroy` callbacks registered during execution of this renderer.
     * @type {(() => void)[] | undefined}
     */
    __privateAdd(this, _on_destroy);
    /**
     * Whether this renderer is a component body.
     * @type {boolean}
     */
    __privateAdd(this, _is_component_body, false);
    /**
     * The type of string content that this renderer is accumulating.
     * @type {RendererType}
     */
    __publicField(this, "type");
    /** @type {Renderer | undefined} */
    __privateAdd(this, _parent);
    /**
     * Asynchronous work associated with this renderer
     * @type {Promise<void> | undefined}
     */
    __publicField(this, "promise");
    /**
     * State which is associated with the content tree as a whole.
     * It will be re-exposed, uncopied, on all children.
     * @type {SSRState}
     * @readonly
     */
    __publicField(this, "global");
    /**
     * State that is local to the branch it is declared in.
     * It will be shallow-copied to all children.
     *
     * @type {{ select_value: string | undefined }}
     */
    __publicField(this, "local");
    __privateSet(this, _parent, parent);
    this.global = global;
    this.local = parent ? { ...parent.local } : { select_value: void 0 };
    this.type = parent ? parent.type : "body";
  }
  /**
   * @param {(renderer: Renderer) => void} fn
   */
  head(fn) {
    const head = new _Renderer(this.global, this);
    head.type = "head";
    __privateGet(this, _out).push(head);
    head.child(fn);
  }
  /**
   * @param {(renderer: Renderer) => void} fn
   */
  async(fn) {
    __privateGet(this, _out).push(BLOCK_OPEN);
    this.child(fn);
    __privateGet(this, _out).push(BLOCK_CLOSE);
  }
  /**
   * Create a child renderer. The child renderer inherits the state from the parent,
   * but has its own content.
   * @param {(renderer: Renderer) => MaybePromise<void>} fn
   */
  child(fn) {
    const child = new _Renderer(this.global, this);
    __privateGet(this, _out).push(child);
    const parent = ssr_context;
    set_ssr_context({
      ...ssr_context,
      p: parent,
      c: null,
      r: child
    });
    const result = fn(child);
    set_ssr_context(parent);
    if (result instanceof Promise) {
      if (child.global.mode === "sync") {
        await_invalid();
      }
      result.catch(() => {
      });
      child.promise = result;
    }
    return child;
  }
  /**
   * Create a component renderer. The component renderer inherits the state from the parent,
   * but has its own content. It is treated as an ordering boundary for ondestroy callbacks.
   * @param {(renderer: Renderer) => MaybePromise<void>} fn
   * @param {Function} [component_fn]
   * @returns {void}
   */
  component(fn, component_fn) {
    push();
    const child = this.child(fn);
    __privateSet(child, _is_component_body, true);
    pop();
  }
  /**
   * @param {Record<string, any>} attrs
   * @param {(renderer: Renderer) => void} fn
   * @param {string | undefined} [css_hash]
   * @param {Record<string, boolean> | undefined} [classes]
   * @param {Record<string, string> | undefined} [styles]
   * @param {number | undefined} [flags]
   * @returns {void}
   */
  select(attrs, fn, css_hash, classes, styles, flags) {
    const { value, ...select_attrs } = attrs;
    this.push(`<select${attributes(select_attrs, css_hash, classes, styles, flags)}>`);
    this.child((renderer2) => {
      renderer2.local.select_value = value;
      fn(renderer2);
    });
    this.push("</select>");
  }
  /**
   * @param {Record<string, any>} attrs
   * @param {string | number | boolean | ((renderer: Renderer) => void)} body
   * @param {string | undefined} [css_hash]
   * @param {Record<string, boolean> | undefined} [classes]
   * @param {Record<string, string> | undefined} [styles]
   * @param {number | undefined} [flags]
   */
  option(attrs, body, css_hash, classes, styles, flags) {
    __privateGet(this, _out).push(`<option${attributes(attrs, css_hash, classes, styles, flags)}`);
    const close = (renderer2, value, { head, body: body2 }) => {
      if ("value" in attrs) {
        value = attrs.value;
      }
      if (value === this.local.select_value) {
        __privateGet(renderer2, _out).push(" selected");
      }
      __privateGet(renderer2, _out).push(`>${body2}</option>`);
      if (head) {
        renderer2.head((child) => child.push(head));
      }
    };
    if (typeof body === "function") {
      this.child((renderer2) => {
        var _a, _b;
        const r = new _Renderer(this.global, this);
        body(r);
        if (this.global.mode === "async") {
          return __privateMethod(_a = r, _Renderer_instances, collect_content_async_fn).call(_a).then((content) => {
            close(renderer2, content.body.replaceAll("<!---->", ""), content);
          });
        } else {
          const content = __privateMethod(_b = r, _Renderer_instances, collect_content_fn).call(_b);
          close(renderer2, content.body.replaceAll("<!---->", ""), content);
        }
      });
    } else {
      close(this, body, { body });
    }
  }
  /**
   * @param {(renderer: Renderer) => void} fn
   */
  title(fn) {
    const path = this.get_path();
    const close = (head) => {
      this.global.set_title(head, path);
    };
    this.child((renderer2) => {
      var _a, _b;
      const r = new _Renderer(renderer2.global, renderer2);
      fn(r);
      if (renderer2.global.mode === "async") {
        return __privateMethod(_a = r, _Renderer_instances, collect_content_async_fn).call(_a).then((content) => {
          close(content.head);
        });
      } else {
        const content = __privateMethod(_b = r, _Renderer_instances, collect_content_fn).call(_b);
        close(content.head);
      }
    });
  }
  /**
   * @param {string | (() => Promise<string>)} content
   */
  push(content) {
    if (typeof content === "function") {
      this.child(async (renderer2) => renderer2.push(await content()));
    } else {
      __privateGet(this, _out).push(content);
    }
  }
  /**
   * @param {() => void} fn
   */
  on_destroy(fn) {
    (__privateGet(this, _on_destroy) ?? __privateSet(this, _on_destroy, [])).push(fn);
  }
  /**
   * @returns {number[]}
   */
  get_path() {
    return __privateGet(this, _parent) ? [...__privateGet(this, _parent).get_path(), __privateGet(__privateGet(this, _parent), _out).indexOf(this)] : [];
  }
  /**
   * @deprecated this is needed for legacy component bindings
   */
  copy() {
    const copy = new _Renderer(this.global, __privateGet(this, _parent));
    __privateSet(copy, _out, __privateGet(this, _out).map((item) => item instanceof _Renderer ? item.copy() : item));
    copy.promise = this.promise;
    return copy;
  }
  /**
   * @param {Renderer} other
   * @deprecated this is needed for legacy component bindings
   */
  subsume(other) {
    if (this.global.mode !== other.global.mode) {
      throw new Error(
        "invariant: A renderer cannot switch modes. If you're seeing this, there's a compiler bug. File an issue!"
      );
    }
    this.local = other.local;
    __privateSet(this, _out, __privateGet(other, _out).map((item) => {
      if (item instanceof _Renderer) {
        item.subsume(item);
      }
      return item;
    }));
    this.promise = other.promise;
    this.type = other.type;
  }
  get length() {
    return __privateGet(this, _out).length;
  }
  /**
   * Only available on the server and when compiling with the `server` option.
   * Takes a component and returns an object with `body` and `head` properties on it, which you can use to populate the HTML when server-rendering your app.
   * @template {Record<string, any>} Props
   * @param {Component<Props>} component
   * @param {{ props?: Omit<Props, '$$slots' | '$$events'>; context?: Map<any, any>; idPrefix?: string }} [options]
   * @returns {RenderOutput}
   */
  static render(component, options = {}) {
    let sync;
    const result = (
      /** @type {RenderOutput} */
      {}
    );
    Object.defineProperties(result, {
      html: {
        get: () => {
          var _a;
          return (sync ?? (sync = __privateMethod(_a = _Renderer, _Renderer_static, render_fn).call(_a, component, options))).body;
        }
      },
      head: {
        get: () => {
          var _a;
          return (sync ?? (sync = __privateMethod(_a = _Renderer, _Renderer_static, render_fn).call(_a, component, options))).head;
        }
      },
      body: {
        get: () => {
          var _a;
          return (sync ?? (sync = __privateMethod(_a = _Renderer, _Renderer_static, render_fn).call(_a, component, options))).body;
        }
      },
      then: {
        value: (
          /**
           * this is not type-safe, but honestly it's the best I can do right now, and it's a straightforward function.
           *
           * @template TResult1
           * @template [TResult2=never]
           * @param { (value: SyncRenderOutput) => TResult1 } onfulfilled
           * @param { (reason: unknown) => TResult2 } onrejected
           */
          (onfulfilled, onrejected) => {
            var _a;
            {
              experimental_async_ssr();
              const result2 = sync ?? (sync = __privateMethod(_a = _Renderer, _Renderer_static, render_fn).call(_a, component, options));
              const user_result = onfulfilled({
                head: result2.head,
                body: result2.body,
                html: result2.body
              });
              return Promise.resolve(user_result);
            }
          }
        )
      }
    });
    return result;
  }
};
_out = new WeakMap();
_on_destroy = new WeakMap();
_is_component_body = new WeakMap();
_parent = new WeakMap();
_Renderer_instances = new WeakSet();
collect_on_destroy_fn = function* () {
  var _a;
  for (const component of __privateMethod(this, _Renderer_instances, traverse_components_fn).call(this)) {
    yield* __privateMethod(_a = component, _Renderer_instances, collect_ondestroy_fn).call(_a);
  }
};
traverse_components_fn = function* () {
  var _a;
  for (const child of __privateGet(this, _out)) {
    if (typeof child !== "string") {
      yield* __privateMethod(_a = child, _Renderer_instances, traverse_components_fn).call(_a);
    }
  }
  if (__privateGet(this, _is_component_body)) {
    yield this;
  }
};
collect_ondestroy_fn = function* () {
  var _a;
  if (__privateGet(this, _on_destroy)) {
    for (const fn of __privateGet(this, _on_destroy)) {
      yield fn;
    }
  }
  for (const child of __privateGet(this, _out)) {
    if (child instanceof _Renderer && !__privateGet(child, _is_component_body)) {
      yield* __privateMethod(_a = child, _Renderer_instances, collect_ondestroy_fn).call(_a);
    }
  }
};
_Renderer_static = new WeakSet();
render_fn = function(component, options) {
  var _a, _b, _c;
  var previous_context = ssr_context;
  try {
    const renderer2 = __privateMethod(_a = _Renderer, _Renderer_static, open_render_fn).call(_a, "sync", component, options);
    const content = __privateMethod(_b = renderer2, _Renderer_instances, collect_content_fn).call(_b);
    return __privateMethod(_c = _Renderer, _Renderer_static, close_render_fn).call(_c, content, renderer2);
  } finally {
    abort();
    set_ssr_context(previous_context);
  }
};
render_async_fn = async function(component, options) {
  var _a, _b, _c;
  var previous_context = ssr_context;
  try {
    const renderer2 = __privateMethod(_a = _Renderer, _Renderer_static, open_render_fn).call(_a, "async", component, options);
    const content = await __privateMethod(_b = renderer2, _Renderer_instances, collect_content_async_fn).call(_b);
    return __privateMethod(_c = _Renderer, _Renderer_static, close_render_fn).call(_c, content, renderer2);
  } finally {
    abort();
    set_ssr_context(previous_context);
  }
};
/**
 * Collect all of the code from the `out` array and return it as a string, or a promise resolving to a string.
 * @param {AccumulatedContent} content
 * @returns {AccumulatedContent}
 */
collect_content_fn = function(content = { head: "", body: "" }) {
  var _a;
  for (const item of __privateGet(this, _out)) {
    if (typeof item === "string") {
      content[this.type] += item;
    } else if (item instanceof _Renderer) {
      __privateMethod(_a = item, _Renderer_instances, collect_content_fn).call(_a, content);
    }
  }
  return content;
};
collect_content_async_fn = async function(content = { head: "", body: "" }) {
  var _a;
  await this.promise;
  for (const item of __privateGet(this, _out)) {
    if (typeof item === "string") {
      content[this.type] += item;
    } else if (item instanceof _Renderer) {
      await __privateMethod(_a = item, _Renderer_instances, collect_content_async_fn).call(_a, content);
    }
  }
  return content;
};
open_render_fn = function(mode, component, options) {
  const renderer2 = new _Renderer(
    new SSRState(mode, options.idPrefix ? options.idPrefix + "-" : "")
  );
  renderer2.push(BLOCK_OPEN);
  if (options.context) {
    push();
    ssr_context.c = options.context;
    ssr_context.r = renderer2;
  }
  component(renderer2, options.props ?? {});
  if (options.context) {
    pop();
  }
  renderer2.push(BLOCK_CLOSE);
  return renderer2;
};
close_render_fn = function(content, renderer2) {
  var _a;
  for (const cleanup of __privateMethod(_a = renderer2, _Renderer_instances, collect_on_destroy_fn).call(_a)) {
    cleanup();
  }
  let head = content.head + renderer2.global.get_title();
  let body = content.body;
  for (const { hash, code } of renderer2.global.css) {
    head += `<style id="${hash}">${code}</style>`;
  }
  return {
    head,
    body
  };
};
__privateAdd(_Renderer, _Renderer_static);
let Renderer = _Renderer;
class SSRState {
  /**
   * @param {'sync' | 'async'} mode
   * @param {string} [id_prefix]
   */
  constructor(mode, id_prefix = "") {
    /** @readonly @type {'sync' | 'async'} */
    __publicField(this, "mode");
    /** @readonly @type {() => string} */
    __publicField(this, "uid");
    /** @readonly @type {Set<{ hash: string; code: string }>} */
    __publicField(this, "css", /* @__PURE__ */ new Set());
    /** @type {{ path: number[], value: string }} */
    __privateAdd(this, _title, { path: [], value: "" });
    this.mode = mode;
    let uid = 1;
    this.uid = () => `${id_prefix}s${uid++}`;
  }
  get_title() {
    return __privateGet(this, _title).value;
  }
  /**
   * Performs a depth-first (lexicographic) comparison using the path. Rejects sets
   * from earlier than or equal to the current value.
   * @param {string} value
   * @param {number[]} path
   */
  set_title(value, path) {
    const current = __privateGet(this, _title).path;
    let i = 0;
    let l = Math.min(path.length, current.length);
    while (i < l && path[i] === current[i]) i += 1;
    if (path[i] === void 0) return;
    if (current[i] === void 0 || path[i] > current[i]) {
      __privateGet(this, _title).path = path;
      __privateGet(this, _title).value = value;
    }
  }
}
_title = new WeakMap();
const INVALID_ATTR_NAME_CHAR_REGEX = /[\s'">/=\u{FDD0}-\u{FDEF}\u{FFFE}\u{FFFF}\u{1FFFE}\u{1FFFF}\u{2FFFE}\u{2FFFF}\u{3FFFE}\u{3FFFF}\u{4FFFE}\u{4FFFF}\u{5FFFE}\u{5FFFF}\u{6FFFE}\u{6FFFF}\u{7FFFE}\u{7FFFF}\u{8FFFE}\u{8FFFF}\u{9FFFE}\u{9FFFF}\u{AFFFE}\u{AFFFF}\u{BFFFE}\u{BFFFF}\u{CFFFE}\u{CFFFF}\u{DFFFE}\u{DFFFF}\u{EFFFE}\u{EFFFF}\u{FFFFE}\u{FFFFF}\u{10FFFE}\u{10FFFF}]/u;
function render(component, options = {}) {
  return Renderer.render(
    /** @type {Component<Props>} */
    component,
    options
  );
}
function attributes(attrs, css_hash, classes, styles, flags = 0) {
  if (styles) {
    attrs.style = to_style(attrs.style, styles);
  }
  if (attrs.class) {
    attrs.class = clsx(attrs.class);
  }
  if (css_hash || classes) {
    attrs.class = to_class(attrs.class, css_hash, classes);
  }
  let attr_str = "";
  let name;
  const is_html = (flags & ELEMENT_IS_NAMESPACED) === 0;
  const lowercase = (flags & ELEMENT_PRESERVE_ATTRIBUTE_CASE) === 0;
  const is_input = (flags & ELEMENT_IS_INPUT) !== 0;
  for (name in attrs) {
    if (typeof attrs[name] === "function") continue;
    if (name[0] === "$" && name[1] === "$") continue;
    if (INVALID_ATTR_NAME_CHAR_REGEX.test(name)) continue;
    var value = attrs[name];
    if (lowercase) {
      name = name.toLowerCase();
    }
    if (is_input) {
      if (name === "defaultvalue" || name === "defaultchecked") {
        name = name === "defaultvalue" ? "value" : "checked";
        if (attrs[name]) continue;
      }
    }
    attr_str += attr(name, value, is_html && is_boolean_attribute(name));
  }
  return attr_str;
}
function attr_class(value, hash, directives) {
  var result = to_class(value, hash, directives);
  return result ? ` class="${escape_html(result, true)}"` : "";
}
function sanitize_props(props) {
  const { children, $$slots, ...sanitized } = props;
  return sanitized;
}
function bind_props(props_parent, props_now) {
  for (const key in props_now) {
    const initial_value = props_parent[key];
    const value = props_now[key];
    if (initial_value === void 0 && value !== void 0 && Object.getOwnPropertyDescriptor(props_parent, key)?.set) {
      props_parent[key] = value;
    }
  }
}
function ensure_array_like(array_like_or_iterator) {
  if (array_like_or_iterator) {
    return array_like_or_iterator.length !== void 0 ? array_like_or_iterator : Array.from(array_like_or_iterator);
  }
  return [];
}
const contexts = /* @__PURE__ */ new WeakMap();
const ID_PREFIX = "s";
function getContext(rendererContextResult) {
  if (contexts.has(rendererContextResult)) {
    return contexts.get(rendererContextResult);
  }
  const ctx = {
    currentIndex: 0,
    get id() {
      return ID_PREFIX + this.currentIndex.toString();
    }
  };
  contexts.set(rendererContextResult, ctx);
  return ctx;
}
function incrementId(rendererContextResult) {
  const ctx = getContext(rendererContextResult);
  const id = ctx.id;
  ctx.currentIndex++;
  return id;
}
function check(Component) {
  if (typeof Component !== "function") return false;
  const componentString = Component.toString();
  return componentString.includes("$$payload") || componentString.includes("$$renderer");
}
function needsHydration(metadata) {
  return metadata?.astroStaticSlot ? !!metadata.hydrate : true;
}
async function renderToStaticMarkup(Component, props, slotted, metadata) {
  const tagName = needsHydration(metadata) ? "astro-slot" : "astro-static-slot";
  let children = void 0;
  let $$slots = void 0;
  let idPrefix;
  if (this && this.result) {
    idPrefix = incrementId(this.result);
  }
  const renderProps = {};
  for (const [key, value] of Object.entries(slotted)) {
    $$slots ?? ($$slots = {});
    if (key === "default") {
      $$slots.default = true;
      children = createRawSnippet(() => ({
        render: () => `<${tagName}>${value}</${tagName}>`
      }));
    } else {
      $$slots[key] = createRawSnippet(() => ({
        render: () => `<${tagName} name="${key}">${value}</${tagName}>`
      }));
    }
    const slotName = key === "default" ? "children" : key;
    renderProps[slotName] = createRawSnippet(() => ({
      render: () => `<${tagName}${key !== "default" ? ` name="${key}"` : ""}>${value}</${tagName}>`
    }));
  }
  const result = await render(Component, {
    props: {
      ...props,
      children,
      $$slots,
      ...renderProps
    },
    idPrefix
  });
  return { html: result.body };
}
const renderer = {
  name: "@astrojs/svelte",
  check,
  renderToStaticMarkup,
  supportsAstroStaticSlot: true
};
var server_default = renderer;
const renderers = [Object.assign({ "name": "@astrojs/svelte", "clientEntrypoint": "@astrojs/svelte/client.js", "serverEntrypoint": "@astrojs/svelte/server.js" }, { ssr: server_default })];
const env_d = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
const global_d = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
const rehypeComponentAdmonition = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
const rehypeComponentGithubCard = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
const remarkDirectiveRehype = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
const remarkExcerpt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null
}, Symbol.toStringTag, { value: "Module" }));
export {
  attr_class as a,
  attr as b,
  ensure_array_like as c,
  bind_props as d,
  escape_html as e,
  sanitize_props as f,
  attributes as g,
  env_d as h,
  global_d as i,
  rehypeComponentAdmonition as j,
  rehypeComponentGithubCard as k,
  remarkDirectiveRehype as l,
  remarkExcerpt as m,
  renderers as r,
  ssr_context as s
};
