import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "";
const frontmatter = { "title": "bb", "published": "2025-09-08T00:00:00.000Z", "description": "", "tags": ["Uncategorized"], "category": "Uncategorized", "draft": false, "minutes": 1, "words": 0, "excerpt": "" };
const file = "D:/github-git/fuwari-blog/src/content/spec/bb.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
