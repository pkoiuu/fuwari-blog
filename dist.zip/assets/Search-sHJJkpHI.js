import { b as attr, c as ensure_array_like, e as escape_html } from "./remark-excerpt-Ct7uGJLc.js";
import { u as url, i as i18n, I as I18nKey } from "./content-utils-BhOblCvP.js";
import { I as Icon, h as html } from "./Icon-DCx2UD_F.js";
function Search($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let keywordDesktop = "";
    let keywordMobile = "";
    let result = [];
    [
      {
        url: url("/"),
        meta: { title: "This Is a Fake Search Result" },
        excerpt: "Because the search cannot work in the <mark>dev</mark> environment."
      },
      {
        url: url("/"),
        meta: { title: "If You Want to Test the Search" },
        excerpt: "Try running <mark>npm build && npm preview</mark> instead."
      }
    ];
    $$renderer2.push(`<div id="search-bar" class="hidden lg:flex items-center h-11 rounded-full bg-black/[0.04] hover:bg-black/[0.06] transition-all duration-300 px-4 cursor-text">`);
    Icon($$renderer2, {
      name: "material-symbols:search-rounded",
      class: "text-xl text-black/30 transition"
    });
    $$renderer2.push(`<!----> <input id="search-input-desktop" type="text"${attr("placeholder", i18n(I18nKey.search))}${attr("value", keywordDesktop)} class="input-reset ml-2 text-sm text-black/50 placeholder-black/30 bg-transparent outline-none w-24 focus:w-48 transition-all duration-300"/></div> <button id="search-switch" aria-label="Search" class="btn-plain scale-animation rounded-lg h-11 w-11 lg:hidden">`);
    Icon($$renderer2, { name: "material-symbols:search-rounded", class: "text-2xl" });
    $$renderer2.push(`<!----></button> <div id="search-panel" class="float-panel float-panel-closed absolute z-50 right-0 top-20 w-[calc(100vw-2rem)] lg:w-[30rem] max-w-[30rem] rounded-2xl p-4 bg-[var(--card-bg)] transition shadow-xl border border-[var(--line-divider)]"><div class="flex lg:hidden items-center h-10 rounded-full bg-black/[0.04] px-4 mb-4">`);
    Icon($$renderer2, {
      name: "material-symbols:search-rounded",
      class: "text-lg text-black/30 transition"
    });
    $$renderer2.push(`<!----> <input type="text"${attr("placeholder", i18n(I18nKey.search))}${attr("value", keywordMobile)} class="input-reset ml-2 text-sm text-black/50 placeholder-black/30 bg-transparent outline-none w-full"/></div> <div class="max-h-[60vh] overflow-y-auto">`);
    {
      $$renderer2.push("<!--[!-->");
      if (result.length > 0) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<div class="space-y-2"><!--[-->`);
        const each_array = ensure_array_like(result);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let item = each_array[$$index];
          $$renderer2.push(`<a${attr("href", item.url)} class="block p-3 rounded-xl hover:bg-[var(--btn-plain-bg-hover)] active:bg-[var(--btn-plain-bg-active)] transition-colors"><div class="font-medium text-[var(--primary)] line-clamp-1">${escape_html(item.meta.title)}</div> <div class="text-sm text-black/50 line-clamp-2 mt-1">${html(item.excerpt)}</div></a>`);
        }
        $$renderer2.push(`<!--]--></div>`);
      } else {
        $$renderer2.push("<!--[!-->");
        {
          $$renderer2.push("<!--[!-->");
          $$renderer2.push(`<div class="text-center py-8 text-black/30">${escape_html(i18n(I18nKey.typeToSearch))}</div>`);
        }
        $$renderer2.push(`<!--]-->`);
      }
      $$renderer2.push(`<!--]-->`);
    }
    $$renderer2.push(`<!--]--></div></div>`);
  });
}
export {
  Search as default
};
