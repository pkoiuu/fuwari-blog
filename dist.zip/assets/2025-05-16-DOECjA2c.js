import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => "<p>明天准备摆摊了好期待~</p>";
const frontmatter = { "title": "可爱的小汤圆日记(2025-5-16)", "published": "2025-05-16T00:00:00.000Z", "description": "可爱的小汤圆日记", "tags": ["Uncategorized"], "category": "it", "draft": false, "minutes": 1, "words": 10, "excerpt": "明天准备摆摊了好期待~" };
const file = "D:/github-git/fuwari-blog/src/content/posts/2025-05-16.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
