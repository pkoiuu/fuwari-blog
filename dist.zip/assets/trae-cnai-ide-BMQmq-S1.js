import { c as createComponent, m as maybeRenderHead, u as unescapeHTML, r as renderTemplate } from "./astro/server-C-80V8Is.js";
const html = () => '<p>先来介绍一下</p>\n<p><strong>Trae CN</strong>是字节跳动在中国的原生支持ai ide,其Trae在海外广受好评,Trae内置了免费国外一流AI模型,在国内使用需要神秘的小魔法~Trae CN则是字节跳动在中国大陆推出,使用不需要神秘的魔法</p>\n<p>Trae CN集成了中国一流AI模型(虽然感觉比不上国外…)</p>\n<p>优点:</p>\n<ol>\n<li>Trae CN在国内不需要神秘的小魔法</li>\n</ol>\n<p>2.支持mcp</p>\n<p><strong>3.原生支持ssh连接</strong></p>\n<p>4.界面比较好看</p>\n<p>缺点:</p>\n<p><strong>1.ai速度别人说的是挺快,实际体验下来一般…</strong></p>\n<p><strong>2.ai模型太傻了..没法猜测出我的意思,get不出我的观点</strong></p>\n<p><strong>3.配置有些复杂,完全不适合新手</strong></p>\n<p><strong>4.性能占用非常多,小配置服务器根本使用不了,就比如说2核2G,根本就不要想,在本地需要的资源也非常多,真的很恶心,用一下服务器直接gg</strong></p>\n<p>具体总结</p>\n<p>一坨…最恶心的就是<strong>性能占用</strong>,还有那一个 <strong>sb AI</strong>,真的<strong>非常非常不推荐</strong>,恶心自己, CPU直接飙升…</p>\n<p><img src="https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755933786-20250823072306112473.webp" alt="图片"></p>\n<p>和我的回收站谈情说爱去吧!</p>';
const frontmatter = { "title": "Trae CN字节跳动ai ide使用感受(不推荐)", "published": "2025-08-22T00:00:00.000Z", "description": "先来介绍一下 Trae CN是字节跳动在中国的原生支持ai ide,其Trae在海外广受好评,Trae内置了免费国外一流AI模型,在国内使用需要神秘的小魔法~Trae CN则是字节跳动在中国大陆推出,使用不需要神秘的魔法\n", "tags": ["ai ide", "sb AI", "Trae CN", "使用感受", "字节跳动", "性能占用"], "category": "灵感", "draft": false, "image": "https://cdnkp.hhj520.top/wp-content/uploads/2025/08/1755933786-20250823072306112473.webp", "minutes": 2, "words": 311, "excerpt": "先来介绍一下" };
const file = "D:/github-git/fuwari-blog/src/content/posts/trae-cnai-ide.md";
const url = void 0;
const Content = createComponent((result, _props, slots) => {
  const { layout, ...content } = frontmatter;
  content.file = file;
  content.url = url;
  return renderTemplate`${maybeRenderHead()}${unescapeHTML(html())}`;
});
export {
  Content,
  Content as default,
  file,
  frontmatter,
  url
};
