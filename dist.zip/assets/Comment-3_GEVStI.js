import { c as createComponent, r as renderTemplate, m as maybeRenderHead } from "./astro/server-C-80V8Is.js";
/* empty css                         */
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Comment = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate(_a || (_a = __template(["", `<div id="tcomment" class="twikoo-container" data-astro-cid-ksttp56e> <!-- 加载占位符 - 纯 CSS 实现，零 JS 开销 --> <div class="twikoo-skeleton" id="twikoo-loading" data-astro-cid-ksttp56e> <div class="skeleton-header" data-astro-cid-ksttp56e> <div class="skeleton-avatar" data-astro-cid-ksttp56e></div> <div class="skeleton-info" data-astro-cid-ksttp56e> <div class="skeleton-line short" data-astro-cid-ksttp56e></div> <div class="skeleton-line shorter" data-astro-cid-ksttp56e></div> </div> </div> <div class="skeleton-content" data-astro-cid-ksttp56e> <div class="skeleton-line" data-astro-cid-ksttp56e></div> <div class="skeleton-line medium" data-astro-cid-ksttp56e></div> </div> <div class="skeleton-actions" data-astro-cid-ksttp56e> <div class="skeleton-btn" data-astro-cid-ksttp56e></div> <div class="skeleton-btn" data-astro-cid-ksttp56e></div> </div> </div> <!-- 错误提示容器 --> <div class="twikoo-error" id="twikoo-error" style="display: none;" data-astro-cid-ksttp56e> <div class="error-icon" data-astro-cid-ksttp56e>💬</div> <div class="error-title" data-astro-cid-ksttp56e>评论加载失败</div> <div class="error-desc" data-astro-cid-ksttp56e>请检查网络连接或稍后重试</div> <button class="error-retry" onclick="window.location.reload()" data-astro-cid-ksttp56e>刷新页面</button> </div> </div> <script>
(function() {
  'use strict';
  
  // 配置
  var CONFIG = {
    envId: 'https://plbt.hhj520.top/',
    el: '#tcomment',
    lang: 'zh-CN',
    scriptUrl: 'https://s4.zstatic.net/npm/twikoo@1.6.44/dist/twikoo.min.js'
  };
  
  // 当前页面路径，用于判断是否需要重新初始化
  var currentPath = location.pathname;
  
  // 隐藏加载占位符
  function hideLoading() {
    var loadingEl = document.getElementById('twikoo-loading');
    if (loadingEl) {
      loadingEl.style.opacity = '0';
      setTimeout(function() {
        loadingEl.style.display = 'none';
      }, 300);
    }
  }
  
  // 显示加载占位符（用于重新初始化）
  function showLoading() {
    var loadingEl = document.getElementById('twikoo-loading');
    if (loadingEl) {
      loadingEl.style.display = 'block';
      loadingEl.style.opacity = '1';
    }
  }
  
  // 显示错误提示
  function showError() {
    hideLoading();
    var errorEl = document.getElementById('twikoo-error');
    if (errorEl) {
      errorEl.style.display = 'block';
    }
  }
  
  // 隐藏错误提示
  function hideError() {
    var errorEl = document.getElementById('twikoo-error');
    if (errorEl) {
      errorEl.style.display = 'none';
    }
  }
  
  // 清理已存在的 Twikoo 实例
  function cleanupTwikoo() {
    var container = document.getElementById('tcomment');
    if (container) {
      // 保留骨架屏和错误提示，清理其他内容
      var children = container.children;
      for (var i = children.length - 1; i >= 0; i--) {
        var child = children[i];
        if (child.id !== 'twikoo-loading' && child.id !== 'twikoo-error') {
          container.removeChild(child);
        }
      }
    }
    // 重置 twikoo 全局状态
    if (window.twikoo) {
      window.twikoo = undefined;
    }
  }
  
  // 初始化 Twikoo
  function initTwikoo() {
    var container = document.getElementById('tcomment');
    if (!container) return;
    
    // 检查路径是否变化（Swup 页面切换后）
    if (currentPath !== location.pathname) {
      currentPath = location.pathname;
      cleanupTwikoo();
      showLoading();
      hideError();
    }
    
    // 设置加载超时
    var loadTimeout = setTimeout(function() {
      console.error('[Twikoo] Load timeout');
      showError();
    }, 10000); // 10秒超时
    
    // 加载 Twikoo
    if (typeof twikoo === 'undefined') {
      var script = document.createElement('script');
      script.src = CONFIG.scriptUrl;
      script.async = true;
      script.onload = function() {
        clearTimeout(loadTimeout);
        runTwikoo();
      };
      script.onerror = function() {
        clearTimeout(loadTimeout);
        console.error('[Twikoo] Failed to load script');
        showError();
      };
      document.head.appendChild(script);
    } else {
      clearTimeout(loadTimeout);
      runTwikoo();
    }
  }
  
  function runTwikoo() {
    try {
      if (typeof twikoo === 'undefined' || typeof twikoo.init !== 'function') {
        console.error('[Twikoo] twikoo object not available');
        showError();
        return;
      }
      
      var initResult = twikoo.init({
        envId: CONFIG.envId,
        el: CONFIG.el,
        path: location.pathname,
        lang: CONFIG.lang
      });
      
      // 处理 Promise 返回值
      if (initResult && typeof initResult.then === 'function') {
        initResult.then(function() {
          console.log('[Twikoo] Initialized successfully');
          setTimeout(hideLoading, 500);
        }).catch(function(e) {
          console.error('[Twikoo] Init promise error:', e);
          showError();
        });
      } else {
        // 非 Promise 返回值，直接认为成功
        console.log('[Twikoo] Initialized (sync)');
        setTimeout(hideLoading, 500);
      }
    } catch (e) {
      console.error('[Twikoo] Init error:', e);
      showError();
    }
  }
  
  // 使用 Intersection Observer 延迟加载
  var observer = null;
  function setupObserver() {
    if (observer) {
      observer.disconnect();
    }
    
    if ('IntersectionObserver' in window) {
      observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            initTwikoo();
            observer.disconnect();
          }
        });
      }, { 
        rootMargin: '200px',
        threshold: 0
      });
      
      var container = document.getElementById('tcomment');
      if (container) {
        observer.observe(container);
      }
    } else {
      // 降级处理
      initTwikoo();
    }
  }
  
  // 初始设置
  setupObserver();
  
  // 监听 Swup 页面切换事件
  document.addEventListener('swup:page:view', function() {
    // 路径变化时重新初始化
    if (currentPath !== location.pathname) {
      currentPath = location.pathname;
      cleanupTwikoo();
      showLoading();
      hideError();
      setupObserver();
    }
  });
})();
<\/script> `])), maybeRenderHead());
}, "D:/github-git/fuwari-blog/src/components/Comment.astro", void 0);
export {
  $$Comment as default
};
